# Music prompts: Dark Touch

Status: APPROVED. Proposals for the designer; nothing was generated.

## exploration

- **Use:** Calm layer while the player crosses a section between fights. It is the base layer, and combat and boss crossfade from it. Key (D minor) and tempo (72 BPM) are my assumption, because no document sets them. They are shared by all four cues so the game can crossfade.
- **Tool:** ElevenLabs Music
- **Key / tempo:** D minor, 72 BPM
- **Length:** 120 s, loop: True
- **Listen for:** Whether the legato cello melody clearly leads over a sparse, drone-based bed that feels dark and weighty without getting cheap or fantasy-sparkly, and whether the start and end could join into a seamless loop.

```text
Instrumental dark neoclassical piece for a dark-fantasy game, D minor, 72 BPM. A solo cello plays the lead melody throughout: slow, legato, expressive, with long bowed notes and a warm, slightly raw tone. Under it sit a very low sustained drone, sparse soft piano notes and a quiet string pad. Sparse arrangement with lots of space, no percussion, no drums. Large cathedral-like reverb, melancholic and ominous mood, slowly building tension without ever becoming loud. Steady and loopable, no dramatic intro, no final ending, no vocals.
```

## combat

- **Use:** Layer that fades in when a fight starts and crossfades back to exploration when the enemies are dead. It shares the key and tempo of the exploration layer.
- **Tool:** ElevenLabs Music
- **Key / tempo:** D minor, 72 BPM
- **Length:** 120 s, loop: True
- **Listen for:** Whether the cello still leads while the energy clearly rises over exploration, and whether the beat grid would line up when crossfaded with the exploration layer at the same 72 BPM.

```text
Instrumental dark neoclassical battle piece for a dark-fantasy game, D minor, 72 BPM. A solo cello stays the lead melody: strong, accented bowing with a driving rhythmic ostinato of eighth notes, plus short melodic phrases that stay in the same key as a calm version of the theme. Supporting low strings play tense staccato pulses, with deep timpani and low orchestral drum hits on the beat, a dark low drone and a rising string swell. Intense and urgent but still sparse and grounded, heavy and physical, with cathedral reverb. Steady energy suited to a loop, no intro, no final ending, no vocals, no electronic drums, no synth bass.
```

## boss

- **Use:** Layer for the boss fight at the end of the level, crossfaded from combat. It shares the key and tempo of the other layers.
- **Tool:** ElevenLabs Music
- **Key / tempo:** D minor, 72 BPM
- **Length:** 120 s, loop: True
- **Listen for:** Whether it feels clearly bigger, darker and more threatening than combat while the cello stays the lead and the tempo stays compatible with the other layers.

```text
Instrumental dark neoclassical boss-fight piece for a dark-fantasy game, D minor, 72 BPM. A solo cello plays the lead melody in a low, powerful register, with broad, heavy, passionate bowing and a menacing variation of a slow minor theme. Beneath it: a massive sustained low drone, full dark string section with tremolo, slow heavy orchestral percussion and booming low drums on the downbeats, deep brass-like low pads and a distant, wordless, ominous atmosphere. Epic, tragic and oppressive, bigger and darker than a normal battle but with the cello always in front. Cathedral reverb, steady loopable energy, no intro, no final ending, no vocals, no electronic drums, no synth bass.
```

## raise_motif

- **Use:** Audio signature played when the player raises a soldier with the dark-magic arm. It is a short, iconic cello phrase, trimmed from a roughly 30 s cue. It is the game's key identity sound and is played one-shot on every raise.
- **Tool:** ElevenLabs Music
- **Key / tempo:** D minor, 72 BPM
- **Length:** 30 s, loop: False, keep the strongest 6 s
- **Listen for:** Whether one 2 to 8 second stretch (aiming for about 6 s) contains an instantly recognisable cello phrase with a strong rise and a haunting held note, and where to cut it so it works as a repeatable audio signature.

```text
Instrumental dark neoclassical cue for a dark-fantasy game, D minor, 72 BPM. A solo cello plays a short, memorable, iconic melodic motif of four to six notes: a slow rising minor phrase that resolves on a long, held, haunting final note with expressive vibrato. Repeat and develop the motif gently across the piece. Behind it, a deep low drone and a faint, dark string swell that builds as if something is rising from the grave, with large cathedral reverb and a long decaying tail. Very sparse, solemn and ominous, with no drums, no percussion, no vocals, no other lead instrument.
```
