# Spell concept-art prompts: Dark Touch

Status: APPROVED. For GPT image generation.

## Raise

**Designer's idea:** The mob rises slowly in swirling smoke toward the sky, levitates 2 s while its material gradually changes and the summon aura appears, then drops and is functional.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers is stretched toward a fallen soldier. The soldier rises slowly and levitates a metre above the ground in smoke spiralling up toward the sky. Its body is mid-transformation: burnt orange and ivory cloth fading into cold slate and ashen blue-grey with pale skin, emissive cyan veins spreading across it. A rank aura gathers around it. A desaturated battlefield background, with bold silhouettes readable from far away. No text, no logo, no watermark.
```

## Reap

**Designer's idea:** The bite pretends to eat the corpse for 2 s; the corpse bleeds at each bite and gently explodes at the end in a mix of blood and cyan magic.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers is held over the corpse of a fallen enemy wearing burnt orange and ivory cloth with warm steel armour. Spectral cyan-turquoise jaws bite into the body, and dark blood spurts at each bite. The corpse is swelling and bursting softly in a gentle burst of red blood mixed with glowing cyan-turquoise magic, with drifting wisps. Clear silhouettes, slightly desaturated ground, readable from far away. No text, no logo, no watermark.
```

## Hunger

**Designer's idea:** A bite Niagara on the chosen mob: two curved arcs of fangs snap shut, then a bright star flash with thin sparks, in the arm's cyan-turquoise, not orange.

**Aspect:** 16:9

```text
Stylised dark-fantasy effect study of a bite spell on one of the hero's own raised soldiers, a cold slate-grey and ashen blue-grey spectral warrior with cyan veins, wrapped in a rank aura with a little smoke that dominates its palette. Two glowing curved arcs of pointed fangs, one above and one below, snap shut on it, drawn in the cyan-turquoise of the hero's spectral right arm. Right after the bite, a bright four-point star flash bursts out with thin radiating sparks. Strong readable shapes against a slightly desaturated dark background, viewed from behind and above the hero. No text, no logo, no watermark.
```

## Grasp

**Designer's idea:** A round ground zone like Raw Nova; ghostly hands come out of the ground and grab enemy legs, 3 pairs of arms around each target, scaled to the mob's size.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with clawed fingers is pressed toward the ground. A large glowing circle on the ground marks the zone. Inside it, three enemies of different sizes in burnt orange and ivory gear are held at the legs by ghostly cyan-turquoise hands rising from the soil, exactly three pairs of arms around each one, longer and thicker on the biggest mob. Slightly desaturated terrain, bold readable silhouettes. No text, no logo, no watermark.
```

## Swap

**Designer's idea:** The camera travels to the swap target first; smoke appears on the player and the targeted summon, hiding the swap for a clean transition.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art of the swap moment, seen from behind and above the hero. The hero, with his translucent cyan-turquoise spectral right arm with long clawed fingers extended, is wrapped in a thick billowing cloud of dark smoke, laced with cyan-turquoise wisps. Several metres ahead, one raised soldier in cold slate grey and ashen blue-grey with cyan veins is hidden in the same kind of smoke. A faint cyan trail links the two clouds. Clean desaturated battlefield, simple readable shapes. No text, no logo, no watermark.
```

## Frenzy

**Designer's idea:** A shout animation on the player; the soldiers' aura doubles in volume and a transparent red circle at their feet shows the buff.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art, seen from behind and above the hero, who throws his head back in a roaring shout, his translucent cyan-turquoise spectral right arm with long clawed fingers flung wide. In front of him stand three raised soldiers in cold slate grey and ashen blue-grey with cyan veins, each wrapped in a rank aura now twice as big and billowing. Under each soldier's feet lies a transparent red circle glowing on the ground. Slightly desaturated ground, bold silhouettes readable from far away. No text, no logo, no watermark.
```

## Rot

**Designer's idea:** Cyan-turquoise veins of rot crawl over the cursed enemy from where the curse landed and pulse with each damage tick; a thin thread links the arm to the target at the cast.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers points forward. A thin cyan-turquoise thread links his hand to the main target, an enemy wearing burnt orange and ivory cloth with warm steel armour. Glowing cyan-turquoise veins crawl across its body from the point where the curse struck, pulsing bright. Two other enemies nearby show smaller patches of the same veins, so several curses read clearly. Slightly desaturated background, bold readable silhouettes. No text, no logo, no watermark.
```

## Power of Below

**Designer's idea:** A shout animation; the arm's aura spreads over the whole body, with a transparent verdâtre (cyan-turquoise) circle under the character for the buff's duration.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art, seen from behind and above the hero, who roars with his head raised and arms open. The aura of his translucent cyan-turquoise spectral right arm with long clawed fingers spreads across his whole body, wrapping horned hood, mantle and armour in flowing cyan-turquoise energy and wisps. Under his feet a large transparent cyan-turquoise circle glows on the ground. A slightly desaturated dark battlefield behind him, strong silhouette readable from far away. No text, no logo, no watermark.
```

## Splinters

**Designer's idea:** Cut stone shards, tombstone fragments, always wrapped in the arm's verdâtre (cyan-turquoise) spell effect.

**Aspect:** 16:9

```text
Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers is thrust forward. A cone of sharp cut-stone shards and broken tombstone fragments with carved edges spreads about 30 degrees from a flat base roughly twice the hero's width right in front of him, ending in a rounded far edge. Each shard is wrapped in glowing cyan-turquoise spell energy and wisps. The shards tear into a group of enemies wearing burnt orange and ivory cloth with warm steel armour, one standing right beside the hero inside the cone. Slightly desaturated graveyard ground, bold readable shapes. No text, no logo, no watermark.
```
