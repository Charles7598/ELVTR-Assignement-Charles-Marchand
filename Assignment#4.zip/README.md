# Assignment 4: Dynamic Content Pipeline for *Dark Touch*

> ## Verify it first (Python 3.9+, standard library only, no login, no API key)
>
> ```bash
> python pipeline.py --self-test
> ```
> Tests every consistency rule and the critic loop, with no model. Expected last line: `23/23 self-tests passed`.
>
> ```bash
> python pipeline.py --replay
> ```
> Runs the whole loop on the recorded model replies from the real run. Expected: the status of the 4 targets below, then `identical to the live run` for all 4 output files.
>
> Both were run from an isolated copy of this folder: [self-test log](verification/self_test_output.txt), [replay log](verification/replay_output.txt).

**Game:** *Dark Touch*, a dark-fantasy roguelike in Unreal Engine 5.8. A one-armed half-dragonkin, given a spectral magic arm by a pact, raises the enemies he kills into an army.

## What it generated

| # | Output | What the game uses it for | Generator | Result |
| --- | --- | --- | --- | --- |
| 1 | [28 sound-effect prompts](outputs/1_sound_prompts.csv) | The sounds still missing from the game's sound tracker | Sound Designer | Approved, round 2 |
| 2 | [4 music prompts](outputs/2_music_prompts.md) | Exploration, combat and boss layers, plus the Raise motif | Music Director | Approved, round 1 |
| 3 | [Section 1 plan](outputs/3_section_1_plan.md) | The first 5 fights, which teach the kit | Level Designer | **Not approved: 2 issues left for the designer** |
| 4 | [9 spell concept-art prompts](outputs/4_spell_concept_prompts.md) | Concepts for spells with no visual yet, from the designer's own ideas | Concept Artist | Approved, round 3 |

## How it works

```text
canon.md, lore.md, GDD, audio + art direction, open questions, tier 1 odds
        |
        v
GENERATE (the project's own agent file as system prompt)
        |
        v
RULE CHECK (Python, no LLM)  +  CRITIC (separate Game Director agent, Opus)
        |
        +-- a rule fails, a blocking issue, or tone below 4/5 --> REVISE (3 rounds at most)
        +-- clean --> APPROVED
        +-- still failing after round 3 --> NEEDS_DESIGNER, never passed off as done
```

The critic separates contradictions from preferences: only a contradiction, or a tone failure against a written rule, can send work back. Anything that quietly decides an item from `open-questions.md` is flagged. The generators may not invent the dark entity, the war or the factions.

## Does it sound like the game?

Mostly, and the critic scored it rather than assuming so: **4/5** on all four final outputs.

- **Worked:** in a first run, the critic gave the section plan **3/5**: "the area names and war-camp staging could belong to any dark-fantasy game". I added the tone gate and tied the task to the story. The next plan has an army paving its road with the town's stolen gravestones, which also connects to the tombstone Splinters: 4/5.
- **Still generic:** the critic keeps pointing at abstract wording in the sound prompts ("dark energy", "necrotic force"), and at the repeated "stylised dark-fantasy" opener in the art prompts.
- **Not judged:** these are prompts. Nobody has listened to or looked at a result yet; the designer judges those by ear and eye.

## What the checks and the critic caught

Full list: [outputs/critic_report.md](outputs/critic_report.md). The clearest cases:

**An outdated sound, caught before regenerating (SND-004).** The game's spear now forms in the air, but the prompt written earlier still said otherwise, and its sibling SND-005 is already imported in the game.

| | Unholy Impale, cast start |
| --- | --- |
| Before | "A deep unholy force building **under the ground**: slow rumble rising…" |
| After | "A long bone spear **forming out of cold smoke** and grinding bone…" |

| Target | Caught by | What |
| --- | --- | --- |
| Audit of existing sounds | Rules | 6 failures: spear from the ground (2), Splinters in bone instead of tombstone (2), a duration ElevenLabs rejects, a missing end tag |
| Audit of existing sounds | Critic | Raw Nova placed around the hero when it lands at the aim; Reap and Hunger not matching their decided looks |
| Sounds, round 1 | Rules | 7 failures, 6 of them durations under ElevenLabs' 0.5 s minimum |
| Concepts | Critic | Enemies in orange *armour* (the palette puts orange on cloth); a Splinters cone starting at a point when the game's has a flat base; a summon drawn without its rank aura |
| Section 1 | Critic | A chest 40 m from the centre of a field 25 m wide; a pack out of Splinters' range from where the plan fires; three spells introduced at once when the GDD says one at a time |

**Left open on purpose (section 1).** The critic still objects to two points after round 3: a soldier raised earlier can break the staged openings, and the fallback for a smaller enemy roll breaks one lesson. Both need a designer decision, so the pipeline stopped there.

**Also flagged for the designer:** the sound prompts assume spells are made of bone, which no document states; fixed 2 s cast sounds will end early when a hit pushes a cast back.

## Scope of this content

- The 3D models are already done.
- The level assets are not done yet: they are not the priority.
- In-game text and dialogue are not done either: we are prototyping combat first, one of the game's two central pillars.
- **Why prompts and not finished files.** I generate sounds myself on ElevenLabs, to keep control of what I validate without burning all the site's credits. Concept art is also prompts because I use the free ChatGPT model, which gives high-quality concepts, so I generate them a few at a time each day myself.

Everything here is a proposal: the pipeline writes only to `outputs/`, never to the game.

## Proof that it ran

| What | Where |
| --- | --- |
| Every model call: full system prompt, message, reply | [recordings/](recordings/) (`*.request.md`, `*.txt`) |
| Timing, exact model and cost of each of the 19 calls | [recordings/index.jsonl](recordings/index.jsonl) |
| Round-by-round journal of the final run | [runs/20261109-015742/journal.json](runs/20261109-015742/journal.json) |
| An earlier run, kept as history (no call trace yet) | [runs/20261109-012722/journal.json](runs/20261109-012722/journal.json) |
| The documents the pipeline read, including the tier 1 odds from an external board | [sources/](sources/), [inputs/rank_odds_tier1.json](inputs/rank_odds_tier1.json) |
| The designer's spell ideas, in his own words | [inputs/spell_ideas.md](inputs/spell_ideas.md) |
| The agents used | [sources/.claude/agents/](sources/.claude/agents/), [agents/concept-artist.md](agents/concept-artist.md) |

**Live run:** `python pipeline.py` needs a logged-in [Claude Code](https://claude.com/claude-code) CLI. The final run took 19 calls and cost $6.09, using Haiku, Sonnet and Opus.

**Limits:** the critic is a model, so it can miss things or disagree between rounds. The rule checks are only as complete as the rules I wrote. Replay proves the loop's logic on recorded replies; it does not call a model.
