# Request: section1_critic_1

Model alias: opus

## System prompt

You are the Game Director for Dark Touch, a dark-fantasy roguelike built in UE5.
You are called at the end of every meaningful task. Your job is to check that what
was just produced matches the GDD and fits with everything already made. You review;
you never build, edit assets, or change the GDD yourself. The game designer has the
final word on every decision.

## What counts as a meaningful task (you are called after each)
- A system or ability implemented or changed
- A batch of assets validated: characters, models, animations, music tracks, sound effects
- A balance change (numbers in data tables)
- A level, room or encounter built
- Any agent proposing something the GDD does not cover

## What you read each time
1. The GDD (source of truth): GDD.md and its companion documents.
2. canon.md: the short list of established facts (names, style rules, palette,
   audio identity, decided numbers). Read it first; it is cheaper than the full GDD.
3. The task report from the agent that did the work: what was made, files, prompts used.
4. reviews.md: your previous verdicts, so you stay consistent with yourself.

## What you check
1. GDD alignment: does it contradict a decided rule? Cite the GDD section.
   Examples of decided rules: casting is blocked while moving; a hit pushes a cast
   back 1.5 s and only stuns interrupt; 10 army slots max; raised soldiers kept
   only on a win; the cello always leads the music.
2. Consistency with existing work: same art style, scale and silhouette language;
   same naming; ability visuals, sounds and numbers that match each other; music
   and sound effects that share one audio identity.
3. Scope: is it inside the current scope (one level with a boss, 6–7
   abilities)? Flag work that grows the scope.
4. Open questions: if the work quietly decides something listed in
   open-questions.md, flag it for the designer instead of accepting it as decided.

## Limits
- You cannot listen to audio or judge animation feel. For those, check the prompts,
  descriptions and metadata, and state that the designer must judge by ear or eye.
- Separate contradictions (the work breaks a decided rule) from preferences (you
  would have done it differently). Only contradictions can block.
- Never invent GDD content. If the GDD is silent, say so and ask.

## Your answer, every time
VERDICT: APPROVED | APPROVED WITH NOTES | CHANGES REQUIRED

For each issue:
- What: one sentence
- Why: the GDD section or the existing asset it conflicts with
- Who fixes it: which agent
- Severity: blocking | should fix | note

GDD UPDATES TO PROPOSE (optional): decisions the designer should add or change.
At most 3 questions for the designer.

Then append a 2–3 line summary of the verdict to reviews.md, and add to canon.md
only facts the designer has validated.

## Reusability
- Besides fit with the game, check that the work keeps game-specific content
  (names, lore, numbers) in data or in /Game/DarkTouch/, and the system itself
  generic. Flag anything that ties a system to Dark Touch without need.


## Running inside the content pipeline
You run headless with no tools and no file access: ignore the instructions above about reviews.md and canon.md.
Review only the output in the message, against the documents in the message. Do not ask for content outside the task.
Reply with one JSON object and nothing else, in this shape:
{"verdict": "APPROVED | APPROVED WITH NOTES | CHANGES REQUIRED",
 "tone_score": 1-5,
 "tone_comment": "does this sound like Dark Touch and not like generic dark fantasy, in one sentence",
 "issues": [{"where": "item id or field", "what": "one sentence", "why": "the document and the rule it breaks",
             "severity": "blocking | should_fix | note",
             "kind": "contradiction | open_question | tone | preference"}]}
Only a real contradiction, or a tone failure against a written rule, may be blocking or should_fix. A preference is a
note. Something that quietly decides an open question is an open_question: blocking if it states it as settled, a note
if it is clearly marked as an assumption. Do not invent rules the documents do not contain.


## Message

<document name="Agentic Documentation/canon.md">
# Dark Touch — Canon

Validated facts only. The Game Director reads this file first on every review.
Only the game designer validates a fact; agents may propose additions, never write them unapproved.
This is the AI-agent version of the GDD. Human versions: GDD.md (6 pages) and GDD-full.md (full reference).
Source of truth for anything not listed here: GDD-full.md and its companion documents.
When a fact changes, GDD.md, GDD-full.md and canon.md are updated together.
Last validated: 2026-10-27

## Identity
- Title: Dark Touch
- Genre: roguelike, army building, aimed WoW-style ability combat
- Engine: UE 5.8; all gameplay code in C++ written by the agents; Blueprints are thin subclasses that only assign assets; the designer builds nothing by hand
- Platform: PC, mouse and keyboard; controller may come later, so never block it
- Camera: behind and above the player, over the shoulder, zoom in and out with the mouse wheel; fixed crosshair at the exact screen centre (0.5, 0.5) (designer, 2026-10-27, W1-GP-30; supersedes the (0.5, 0.35) interpretation of W1-GP-25); spring arm socket offset (X=20, Y=50, Z=70) (Y=50 since 2026-10-27), arm length 200 by default, wheel zoom 50-600, default 200 (designer, 2026-10-27, W1-GP-29: no zoom down to 0, min 50); the mouse always controls the camera, TPS-style, no button to hold (2026-10-27)
- World: Cel'ardor (working name)
- Art style: stylised, in the spirit of Fellowship
- Magic: only dragonkin can wield magic (elemental, arcane, dark); a human body cannot withstand magic without special gear that cancels its side effects; the player wields magic only through the arm from the pact (designer, 2026-10-29)
- Peoples: Mage = dragonkin; Guard, Rogue and Blademaster = human; Tank and Berserker = bull warriors. The Blademaster's gear grants him a little magic, trained to its full potential: his reflecting parry is that magic. Bull warriors are strongly resistant to magic (a counter to mages), very strong against humans, can infuse their gear or body with magic but cannot cast spells (designer, 2026-10-29)
- Player: a half-breed, part dragonkin and part human; had never wielded magic before the pact; the arm is his first magic (designer, 2026-10-29)
- Story: a one-armed half-dragonkin made a pact with an unknown dark entity for a magic arm that casts on its own; wakes in a village during a continent-wide war and raids the enemy army to protect it

## Combat rules
- Abilities are instant or have a cast time
- All instant spells can be cast while moving (designer, 2026-10-27). "No casting while moving" applies only to spells with a cast time, except Grasp, Frenzy, Hunger and Rot (Splinters and Hunger are instant anyway)
- Global cooldown: 1 s by default, set per spell (data): Reap has its own 0.5 s GCD (designer, 2026-10-27, W1-GP-21); Power of Below 0.75 s
- Cast times: Deathbolt 1.5 s (designer, 2026-11-03; was 1.75 s); Unholy Impale and Raw Nova 2 s
- Damage and HP loss are always rounded down to whole numbers
- No dodge: enemy windups are answered by stopping a cast and moving away
- Controls: fully rebindable, bar organised freely like WoW; QWERTY and AZERTY both supported: the game adapts automatically to the connected keyboard layout, number row included (movement ZQSD on AZERTY / WASD on QWERTY, Q and D strafe, the mouse turns the character, jump kept; Deathbolt on the key labelled 3 on either layout; AZERTY/QWERTY fix validated in play by the designer, 2026-10-27, W1-GP-27); spell defaults (to be fitted around the above):  A, E, R, F, 1-5 and Shift + the same (18 slots: 12 spells, 3 golden-slot abilities, 3 command-group keys)
- Taking a hit pushes the current cast back by 1.5 s; each hit pushes back again (no cap on pushbacks per cast); a cast can be pushed back down to 0 s remaining and no further; only stuns interrupt a cast; after a pushback the cast cannot be pushed back again for 0.5 s (hits taken meanwhile cost nothing), a new cast starts unlocked (designer, 2026-11-07)
- A stun cancels the cast in progress, with no other penalty than the stun's duration
- The global cooldown starts at the beginning of the cast
- Spell queue, WoW-style: the next spell can be pressed shortly before the end of the GCD or the cast and fires right away (designer: very important); the queued spell's action-bar button gets a pulsing gold outline (designer, 2026-10-27); the queue is cleared by a stun and by jumping, and by moving only while a cast is in progress (moving without a cast does not clear it, so instants queued while running survive) (designer, 2026-10-27, W1-GP-26)
- Reap is no longer off the GCD: it triggers a GCD of its own, 0.5 s (designer, 2026-10-27, W1-GP-21; supersedes the earlier "Reap off GCD, castable during a cast" answer of W1-GP-09). Reap cannot be cast during another cast or during a GCD: it waits like every other spell (can be queued) (designer, 2026-10-27, W1-GP-24)
- Moving or jumping cancels a cast (shown as a discreet grey Cancelled state, distinct from a stun interruption)
- Cast-time spells are cast on the ground only and standing still: not while jumping or falling, even with no movement key held; leaving the ground cancels a cast in progress (designer, 2026-11-03)
- Aim: fixed crosshair at the exact screen centre (0.5, 0.5) (designer, 2026-10-27, W1-GP-30); the aim trace goes from the camera through the crosshair and its impact point is the target; the spell leaves the character's hand toward that impact point (the offset between camera ray and hand is accepted); the character turns toward the aim when casting and keeps aiming during the cast (designer, 2026-10-27); a switch between raw aim and soft-target assist exists from week 1 for comparison (the final choice is still made in prototyping)
- Stun sources: the Mage's long charged spell, the Blademaster's parry
- Bull warriors (Tank, Berserker) cannot be stunned, as enemies and as soldiers (designer, 2026-10-29)
- Fillers build Souls, spenders consume them

## Resources
- Week 1 provisional numbers (designer, 2026-10-27): player HP 1000, training dummy HP 400 (it dies and respawns), player movement = WoW values (see the movement line, W1-GP-31), Deathbolt 60 base damage, infinite range, fast projectile speed (placeholder, designer will tune)
- Week 1 provisional values, confirmed as provisional (designer, 2026-10-27, W1-GP-20; to adjust after playing): spell queue window 0.4 s; soft-target assist angle 6 degrees, 150 cm around the ray, range 5000 cm; projectile 5000 cm/s, lifetime 10 s, radius 10 cm; dummy respawn 3 s; mouse wheel 50 cm per notch; debug hit 10 damage, debug stun 2 s; enemy overhead HP bar (designer, 2026-10-27, W1-UI-28): 120 x 12 px, 125 cm above the base, visible up to 5000 cm (50 m, designer 2026-10-29), hidden on death, full on revive, no value text
- Movement copies WoW (designer, 2026-10-27, W1-GP-31; 1 yd = 91.44 cm; WoW values, to confirm in game; the Gameplay Programmer may adjust a value after checking sources): run forward, strafe and backward all 640 cm/s (7 yd/s; no backpedal speed, W1-GP-32), gravity 1764 cm/s² (GravityScale 1.80, 19.29 yd/s²), jump take-off 727 cm/s (7.96 yd/s, about a 1.5 m jump), terminal fall speed 5500 cm/s (60.15 yd/s), no air control (trajectory locked at take-off; turning in the air does not change velocity), instant start and stop on the ground
- Facing while moving (designer, 2026-10-27, W1-GP-32): moving backward is as fast as forward (640 cm/s) and the character turns around to face its movement direction and runs toward the camera (no backpedal walk); forward and strafe (Q/D) still face the camera. When casting, the character turns toward the aim; an instant cast while running backward turns to the crosshair to fire, then resumes (main-session default, to confirm in play). Transition animations (180° pivot, turn in place) are being searched by the Animation Scraper.
- HUD layout (designer, 2026-10-27): player HP bar below the action bar; enemy HP bars above their heads (world widget); the week-1 HP bar and 12-slot action bar are provisional, the full HUD frame comes later
- Mouse and action bar (designer, 2026-11-08, for now): right click shows the cursor and the camera stops following the mouse; right click again hides it. With the cursor shown, spells are dragged between action bar slots (swap); the keys stay on the slots
- Pause menu (designer, 2026-11-08): Escape freezes the game and opens Continue, Settings (mouse sensitivity, volume, graphics quality, display), Quit
- Spirit: max 100 at level 1, +20 per player level (380 at level 15)
- Spirit: spent only on Raise and revives; revive cost = 60% of that soldier's raise cost, rounded down (revivePercent on the economy/spirit doc)
- Raise cost: Shadow 50, Asset 75, Ace 110, General 150; +10 per S grade, -10 per B grade (so 20 to 180); numbers on the Rank Odds board, economy/spirit doc; no other spell costs Spirit
- Spirit gains: 50 on entering each section (up to the cap), 5 per Reap, some variant passives; this exchange rate is intended; target: about 2-3 raises per section at tier 1; at tier 20 about 2-3 Generals per section
- HP: no regeneration over time; healed by Hunger and by Reap for HP (2 s cast, 20% of max HP)
- Spirit never regenerates over time; regained a little at each new section, by Reap, and by some variant passives
- Souls: short-loop resource, Soul Shard-style; kills and Reap give no Souls
- Souls: max 6; each spender costs 3; Deathbolt gives 1; Splinters gives 1 (2 with a proc); Rot gives 0; Souls are given only when the spell hits a target, once per cast, a miss or a wall gives none (designer, 2026-11-08)
- No currency: no gold, no shop

## Abilities
- Names are final; Death Nova was renamed Raw Nova and Deathbolt keeps its name (designer, 2026-10-29)
- Aimed: Deathbolt, Unholy Impale, Rot (hitscan), Swap, Raise, Reap (soft targeting decided in prototyping)
- Cone toward the aim: Splinters. Ground circle: Raw Nova, Grasp. Aimed: Hunger
- 7 spells at the start (Deathbolt, Unholy Impale, Splinters, Raw Nova, Raise, Reap, Hunger); 5 unlocked by player level (Grasp, Swap, Frenzy, Rot, Power of Below)
- Variants are equipped in variant slots unlocked by player level (6 by level 15); one variant per spell at most
- Deathbolt: single-target cast-time filler, last in priority
- Unholy Impale: single-target spender
- Unholy Impale look (designer, 2026-11-08): a spear that forms to the right of the crosshair, above the casting arm, during the cast (not in the hand; designer, 2026-11-08: FormOffset 35, 85, 75 from the caster), flies with the Deathbolt's trail, goes half its length into what it hits (wall or enemy), stays 10 s, then shrinks and is destroyed
- Splinters look (designer, 2026-11-08): shards of cut stone, tombstone fragments, always wrapped in the arm's spell effect
- Rot look (designer, 2026-11-08, W2-GP-14): cyan-turquoise veins crawl over the cursed enemy from where the curse landed and pulse brighter with each damage tick; a thin thread links the arm to the target at the cast
- Spell colour (designer, 2026-11-08): when he says "verdâtre" he means the arm's cyan-turquoise
- Raise look (designer, 2026-11-08): the mob rises slowly in smoke swirling toward the sky, levitates for 2 s while its material gradually changes and the summon aura appears, then drops to the ground and is functional
- Hunger look (designer, 2026-11-08): a cyan-turquoise bite effect on the chosen soldier, arcs of fangs snapping shut
- Reap look (designer, 2026-11-08): the bite appears to eat the corpse for 2 s; the corpse bleeds at each bite and gently explodes at the end in a mix of blood and cyan-turquoise magic
- Frenzy look (designer, 2026-11-08): a shout animation on the player; the soldiers' aura doubles in volume and a transparent red circle at their feet shows the buff
- Power of Below look (designer, 2026-11-08): a shout animation; the arm's aura spreads over the whole body and a transparent cyan-turquoise circle sits under the character for the duration of the buff
- Splinters: instant AoE cone toward the aim, 30° wide, starting from a flat base about twice the player's width (hits enemies right next to him), rounded far edge; weak, builds Souls; 2 charges, 5 s recharge per charge (3 s during Power of Below); cone length 40 m (provisional, to check in play, designer 2026-10-29)
- Splinters proc: any player hit except Splinters' own has 10% chance to grant a free Splinters charge and double its next hit; Rot's first hit 10%, later Rot ticks 1%; soldiers' hits never proc
- Splinters: up to 2 procs held, so at most both charges are empowered; never more than 2 charges, never more than double damage per charge
- Free spender proc: each enemy hit by Splinters has 5% chance to make the next spender cost no Souls; only one stored; AoE dominating the rotation is intended
- Splinters proc empowers the charge it grants; with 2 charges already, it empowers an existing charge; with 2 procs active, a third proc is lost
- Raw Nova: AoE spender; a circle on the ground shows the zone during the cast and follows the aim (designer, 2026-11-08)
- Grasp: root (designer, 2026-11-08: ground circle like Raw Nova; every target hit takes low damage and is rooted for 4 s; ghostly hands come out of the ground and grab the legs, 3 pairs of arms around each target, scaled to the size of the mob so it reads on every mob)
- Swap: swap places with a soldier (designer, 2026-11-08: the camera travels to the swap target first; meanwhile smoke appears on the player and the targeted summon, hiding the swap for a clean transition)
- Frenzy: timed buff on soldiers
- Hunger (replaces Death Trap): instant, aimed; targets only the player's own soldiers; hitting one of your summons consumes it, healing the player by its remaining HP; castable while moving; 10 s cooldown; the eaten soldier becomes a corpse again, revivable for 60% of its raise cost (intended loop); Chosen cannot be eaten; heal capped by the eaten soldier's rank: max 30% of player max HP (Shadow), 40% (Asset), 50% (Ace), 60% (General)
- Rot (replaces Flying Filthy Dagger): instant, generates no Souls; hitscan curse on the aimed target, damage every 1 s for 10 s; can be on several enemies at once; recast on a cursed target refreshes the duration to 10 s (no stacking)
- Power of Below: personal offensive cooldown; GCD 0.75 s, cast times halved, spenders instant, Splinters recharge 3 s; lasts 15 s, cooldown 120 s (provisional, designer 2026-10-29); unlocked by player level (Level Unlocks board)
- Base rotation (no talismans): spender (Unholy Impale ST / Raw Nova AoE) if Souls capped (never overcap) > Splinters with proc > spender > Rot on main target if not cursed > Splinters > Deathbolt
- Reap: consume a corpse for a 10 s buff (no Souls) (variants: HP regen, damage, speed), plus a mouse choice after pressing Reap: left click = 5 Spirit (instant), right click = 20% of max HP (2 s cast, stand still, pushback applies); a corpse left by Hunger can be reaped too
- Reap base buff (no Reap variant equipped): every army soldier heals 1% of its HP per second for 10 s
- Each ability has 2 unlockable variants (Reap has 3); variants not yet defined

## Army
- Weapon: a spectral dark-magic arm (no blade): non-physical, translucent, glowing, with wisps and clawed fingers, yet able to strike, grab and hold things; it must stand out in every animation
- Raise: performed with the dark-magic arm, cost by rank and grades, cast time, must be close; any rank the player meets can be raised
- 10 army slots max at endgame
- No orders: soldiers attack the first enemy they see
- 3 command groups, set by drag and drop in the army tab; each group's hotkey selects it and swaps the action bar to the order bar (Attack, Protect, Move), like a WoW Rogue's stealth bar; giving an order swaps back to the spells instantly; pressing the group key again swaps back without an order
- All 10 army slots are open from the start
- Dismissing a soldier frees its slot
- 3 golden army slots: a soldier there gives its type ability to the player as a spell
- Orders: Attack, Protect (attack the biggest threat to the player), Move
- Collection: winning a run adds the soldiers raised and won with; Chosen (soldiers brought from it, 0-3 by player level) stay in it whatever happens
- Each run: bring up to 3 Chosen from the collection (none at level 1), raise the rest on the battlefield
- Raised soldiers: join the collection on a win; lost on a defeat
- Any fallen soldier can be revived for 60% of its raise cost, during combat too: casting Raise on a dead summon revives it (designer, 2026-10-29); a raised soldier not revived before leaving the current section is lost for the run
- All kept soldiers revive automatically when a run ends

## Soldier roster (enemies and soldiers share it)
- Guard: sword and shield footman; sometimes shields up (stands, turns slowly). Combat block v1 (provisional, designer 2026-11-07): 500 HP, sword 40 damage every 2.5 s (was 2 s), reach 2 m, notices the player at 20 m, the player's walking speed; the corpse stays after death. Player ability: Guard, damage reduction for 1.5 s
- Mage: ranged arcane bolts; occasional long charged spell for massive damage that stuns; focuses its biggest threat. Player ability: TBD
- Rogue: dual blades, fast, high damage, squishier than Guards; focuses player and elites; 1 s windup then dash through normal mobs. Player ability: TBD
- Tank (bull warrior, cannot be stunned): armoured, slow, hits hard, very tough. Player ability: Taunt (all nearby enemies focus the Tank, Rogues included)
- Blademaster: two-handed, sturdy, hits hard, fairly fast; occasional parry with a visible windup, sends damage back and stuns. Player ability: Parry (sends an attack back at 2x damage)
- Berserker (bull warrior, cannot be stunned): leaps onto its target; Whirlwind, a quick simple AoE around itself (not a long channel). Targeting: fights melee soldiers first, the strongest first (designer, 2026-10-29); leap range and Whirlwind details TBD. Player ability: TBD
- Elites: any mob can be one; aura, slightly different palette, stat boost
- A raised elite is captured (Pokémon-style) and sent to the collection at the base, not to the run's army; every fallen elite can be captured, with no limit per run
- A captured elite keeps its elite status and stats, but is lost if the player loses the run (no death farming)
- Capture works like a normal raise for now; a special capture (rhythm mini-game?) is planned for later
- The base = the menu between runs, holding the collection: choose Chosen to bring (up to 3), talismans, difficulty
- Player level: max 15; levels 2-15 unlock 5 spells, 6 variant slots, 3 Chosen slots (first at level 2) (order on the Level Unlocks board); levels are gained at the end of a run; experience is kept even on a lost run
- At the base, a Rename button lets the player rename any soldier (optional)

## Names and grades
- Every mob gets a random name from a list of 200 European first names (data/mob-names.csv)
- Alive, all mobs of a type share the same stats
- Hidden grades rolled at random, one per stat: Vitality (max HP), Attack (damage), Speed (cast speed for ranged, movement speed for melee)
- Grades: S = 1.25x, A = 1x, B = 0.75x
- Rank (Solo Leveling-inspired): Shadow = 1, Asset = 2, Ace = 3, General = 4; boosts all stats, never changes grades
- A better rank almost always means a better soldier (intended); grades decide within a rank
- Difficulty tiers are endless; tier 20 = top end game; beating a tier unlocks the next
- Up to tier 20, enemies get stronger through their number and ranks
- Above tier 20: odds and enemy numbers stay as at tier 20; each tier adds +20% damage and HP to every enemy (21: +20%, 22: +40%...); enemies only, not kept when raised or captured
- Enemies per fight: a random number in a range per tier (2-3 at tier 1, 12-15 at tier 20), on the Rank Odds board
- Ranks by tier: Asset from tier 3, Ace from tier 8, General from tier 14; exact rank and grade odds live on the Rank Odds board (source of truth)
- A Chosen above the tier's highest rank fights at that rank
- "Level" means only the player's level (1-15); ranks use a rank number (1-4)
- Effective stat = (Base x Grade) x (1 + (Rank number − 1) x 0.5): Shadow 1x, Asset 1.5x, Ace 2x, General 2.5x
- Rank on enemies: shown on the health bar (default modern WoW retail nameplate style), no effect on the body
- Enemy health bars (designer, 2026-10-29): shown within 50 m of the player; elites have a gold frame; no name over a living mob; the name appears in the widget frame after its death, and when the unit is selected with a left click; a rank symbol sits left of the bar: circle = Shadow, rhombus = Asset, rounded square = Ace, faceted diamond (gem) = General (shapes provisional)
- Elites: gold outline on the health bar
- Rank on corpses: faint aura, weaker than on summons but visible
- Rank on summons: an aura that dominates the summon palette
- Aiming at a corpse opens a world widget above it: name, rank, grade of each stat; gold outline for elites
- Holding Alt shows all health bars and all corpse widgets at once
- Higher difficulty tiers: better odds of high grades

## Gear
- Talismans only, no armour: found in hidden chests or dropped by foes
- Talisman target: 2–3 new talismans unlocked per completed run (drop rate set once fight sizes are known)
- Equip 2 before a run; each boosts the stats of one specific spell

## Run
- Current scope: one level with a boss at the end
- The level is outdoors, 5 sections per run, each of about 5 fights, cleared one after another; no going back to a previous section
- Win: kill the boss. Lose: player HP reaches 0
- Difficulty tiers like Mythic+: stronger mobs, better grade odds, more experience

## Art
- Concepts: GPT images → 3D with Meshy AI
- Animations are authored on the UE5 Mannequin skeleton (SK_Mannequin); a character on another skeleton (the Hero) plays them through an IK Retargeter at runtime
- Python Editor Script Plugin enabled (designer 2026-10-28, W1-TD-42) for editor tooling only: import, naming, cutting and retargeting of animations (Mixamo/GASP → Manny); no gameplay logic in Python, gameplay stays C++
- Hit reactions (designer 2026-10-28, W1-ANIM-44): only the Mixamo "Small" reacts are used, never the "Large" ones; damage feedback must never make the character or mobs step back (in-place, upper body)
- GASP clips: the agent selects the ~40 needed M_Neutral_* clips by script (exact names from the inventory) and migrates them itself, headless (W1-ANIM-43)
- Mixamo clips are converted to the UE5 Mannequin skeleton with Mixamo Converter before import (designer's pipeline, 2026-10-28, W1-ANIM-45): imported directly onto SKM_Manny_Simple / SK_Mannequin, no skinned FBX and no IK retarget; source folder C:\Users\march\Desktop\Mixamo's DarkTouch Assets
- Animation sources, week 1 (2026-10-28): GASP (Epic, Unreal-only licence) for locomotion, pivots, turns, jumps; Rokoko free magic pack + Mixamo for one-hand casts; Mixamo in-place "React" clips for hit reactions, played on the upper body through a per-bone layered blend so the character keeps running; free sources first, no paid packs for now; raw source art (FBX) in UE5 Project/SourceArt/ is never committed (ignored in git, designer 2026-10-28, W1-ANIM-41), only imported .uasset files are
- Player = 1 skeletal mesh (body and cursed arm together, 1 material) shown by the player; designer 2026-11-02: the 2-mesh split caused more problems than it solved
- Hero rigged by AccuRIG (designer 2026-11-02, W1-ANIM-59 option C): Meshy v4 model (Art/Characters/Hero_Meshy_v4: short mantle on the shoulders, no strips down to the hips; cloth simulation later only on the mantle fringes, designer 2026-11-02), AccuRIG rig with Unreal bone names on its OWN skeleton (SK_Hero_AR, SKM_Hero_AR, MI_Hero_v4); the player runs the animation on a hidden SKM_Manny_Simple and the visible Hero copies the pose at runtime through RTG_Manny_to_Hero (C++ URetargetFromParentAnimInstance); all Manny/Mixamo/GASP clips stay on SK_Mannequin. No cloth simulation for now. Before any rig hand-over: the test bench (9 clips, close-ups of hands, elbows, neck, shoulders, cloak) is rendered and checked. The previous Hero (SKM_Hero, hero_v2) stays in the project, unused
- The Hero AccuRIG v4 setup is validated (designer 2026-11-02, W1-ANIM-60). Next: Chaos Cloth on the mantle fringes only (SKM_Hero_AR), done by the main animation session.
- Player locomotion for now: the UE5 template clips (MM_Idle, MF_Unarmed_Jog_*, MM_Jump / Fall_Loop / Land), turn in place off; the GASP clips stay in the project, unused (designer 2026-11-02)
- Main character look: horned hood, ornate golden mask with glowing cyan eyes, tattered olive-green mantle, dark leather armour with gold trims and chains, no long coat (trousers, straps, wrapped boots), athletic build close to Manny; reference images/main-character.png
- The dark-magic arm is cyan-turquoise
- Rank colours: Shadow pale green, Asset purple, Ace black with thin silver edge, General deep red with black outline
- Summon aura: overlay on the skeletal mesh material + small smoke, dominates the base material
- Enemy palette (warm): burnt orange #C8641E, ivory #E8DCC0, warm steel #9A9590, tan leather #8A5A34, warm skin #C99A7A
- Summon palette (cold): slate #5E6670, ashen blue-grey #3E4650, corpse pale #A9B0B0, emissive cyan #3FE0D0
- One material per type; a Raised parameter switches enemy palette to summon palette
- Elites: enemy palette, richer: darker saturated orange, dark-bronze armour, bigger trims

## Audio
- Dark neoclassical; the cello always leads the melody
- No phonk for now; tested only if the music lacks impact (designer, 2026-10-29)
- Adaptive layers: exploration, combat, boss
- Raising a soldier has an iconic cello motif
- Sound effects: generated by the designer on ElevenLabs from the Sound Designer's prompts, on a plan that allows commercial use; tracked in review/sons.csv (designer, 2026-11-07; was: free sound banks CC0, Pixabay, CC-BY)
- Sound tone: dark, grounded, weighty; nothing too fantasy or cheap-sounding (designer, 2026-11-07, W1-SND-02)

## Production rules
- Course end date: 24 November 2026 (designer, 2026-11-07); the demo must be playable by then (the plan assumed 13 December)
- Whole first, then polish: a feature is added complete in a first version on every layer (code, UI, feel and VFX, animation, audio, level); polish comes after
- Everything must be reusable in a future project: generic systems as C++ Actor Components driven by data tables or data assets, UInterfaces, delegates and Gameplay Tags; an automation test for every rule with a number
- Generic systems in the C++ plugin Plugins/GameSystems/ (one module per system); Dark Touch code in Source/DarkTouch/, content in /Game/DarkTouch/; the plugin never references the game module
- Generic names; a README.md per system; systems.md marks each system reusable or game-specific
- Assets (animations, sounds, music) only under licences that allow reuse; source and licence recorded
- Verify before handing over: build the C++ and fix every error and warning, relaunch the editor, run the automation tests, compile and save any Blueprint touched, PIE smoke test when gameplay changed, read the log and crash reports; fix it yourself; never hide an error; after 3 failed tries report it to the designer (rules in the UE5 project's CLAUDE.md, enforced by a hook)

## Tuning boards (source of truth for data tables)
- Level Unlocks board: https://claude.ai/artifact/NqX8sL4fDcjPXyauHew4vz (ArtifactData collection "progression", doc "order": unlocks for levels 2-15 in order)
- Rank Odds board: https://claude.ai/artifact/DfuKmSVMsquH5RjLVcJHt3 (ArtifactData collection "tiers", one doc per tier, plus collection "economy", doc "spirit": raise costs by rank, grade adjustments, revive % of raise cost (revivePercent), section entry, reap, max Spirit base and per level; tiers docs: enemiesMin, enemiesMax, then shadow, asset, ace, general, gradeS, gradeA, gradeB as whole %)
- Tiers above the last row use the last row's odds

## Validated assets
(Add one line per validated asset: name, file, date.)
- Main character concept, front and back: images/main-character.png, 2026-10-22

</document>

<document name="Agentic Documentation/lore.md">
# Dark Touch — Lore

Part of the [Dark Touch GDD](GDD.md). Simple for now; to be expanded later. Magic, peoples and the player's origin validated by the designer on 2026-10-29.

## The world

**Cel'ardor** (working name). The whole continent is at war.

## The story

You are a half-breed, part dragonkin and part human, who lost an arm and had never wielded magic. You accepted a pact with a dark entity you know little about. It gave you a magic arm that casts spells on its own, granting you the powers of a necromancer. The arm is your first magic.

You wake up in a small town. To protect the village, you raid the enemy army before it can attack. You know you must learn magic from scratch with this new power, so you are glad to start by protecting a small village, and later bring destruction to your enemies once you have mastered it.

## Magic

- **Only the dragonkin can wield magic:** elemental, arcane and dark magic alike.
- **A human body cannot withstand magic.** Without special gear that cancels its side effects, a human cannot use it.
- **The player wields magic only through the arm** the dark entity gave him in the pact.

## Peoples

- **Dragonkin** — the born wielders of magic. The Mages are dragonkin.
- **Humans** — no magic of their own. The Guards, Rogues and Blademasters are human. A few gain access to a little of it through special gear. The **Blademaster** is one of them: he owns gear that lets him use a little magic, and he has trained to push that little to its full potential. His parry, which reflects damage back, is that magic.
- **Bull warriors** — the race of the Tanks and the Berserkers. They have a strong resistance to magic, which makes them a natural counter to mages, and their strength makes them very dangerous against humans. They can use magic, but only to infuse their gear or their own body; they cannot cast spells. Bull warriors cannot be stunned.
- **The player** — a half-breed, part dragonkin and part human. He had never wielded magic before the pact.

## Still to write

The entity, the war and its factions. See [Open questions](open-questions.md).

</document>

<document name="Agentic Documentation/open-questions.md">
# Dark Touch — Open Questions

Decisions still to make for the [Dark Touch GDD](GDD.md). Tick an item when it is decided, then move the decision into the GDD or its companion documents.

## Combat and abilities

- [ ] The two variants of each ability.
- [ ] Instant spells: castable in the air? (for now yes, like while moving)
- [ ] Whether aimed abilities get a soft-targeting assist or stay raw aim (decided during prototyping). Week 1: a switch lets the designer compare both; final choice still open.
- [ ] The AoE rotation beyond Raw Nova, and how talismans change the rotation.
- [ ] Which variant passives give Spirit, and how much.
- [ ] How many Souls a kill gives, and how many a Reap gives.
- [ ] Other stun sources, beyond the Mage's charged spell and the Blademaster's parry; can the player stun enemies?

## Army and soldiers

- [ ] Player abilities granted by Mages, Rogues and Berserkers.
- [ ] Berserker: leap range and Whirlwind details (targeting decided: melee soldiers first, strongest first).
- [ ] Grade and rank odds per difficulty tier.
- [ ] Is the collection at the base limited in size?
- [ ] Later: the special capture mechanic (a rhythm mini-game aligning auras, or another idea).

## Enemies and level

- [ ] Enemy roster for the level: which types appear, how often, how many elites.
- [ ] The boss of the level: design and mechanics (idea: adds spawning mid-fight to switch between single target and AoE).
- [ ] Level layout: how many sections, their size and shape, what marks the exit of a section, hidden chest placement, run length for the one-level demo.

## Progression

- [ ] Talismans: stats they boost, rarity, how many can be owned, whether found ones are kept after a death; the drop rate once fight sizes are known (target: 2–3 per completed run).
- [ ] The experience curve: how much experience a run gives and how much each level needs.
- [ ] The talent list, including talents that change how Souls are gained.
- [ ] What each variant does.
- [ ] Tuning the Rank Odds board (enemies per fight, rank and grade odds) in playtests.

## Presentation

- [ ] The mantle: light physics on its back strips, or stiff skinning only?
- [ ] UI: screen order, and the UI Designer's model.
- [ ] Default assignment of the 18 key slots (12 spells, 3 golden-slot abilities, 3 command-group keys) and of the 3 orders on the order bar.
- [ ] Accessibility options, such as reducing camera shake.
- [ ] Lore beyond the opening story: the entity, the war, the factions.
- [ ] Bull warriors cannot be stunned (decided). Beyond that, does their magic resistance become a combat rule (less damage from the player's spells, resistance to roots such as Grasp), or stay lore only?

## Balance

- [ ] All numbers: damage, HP, cooldowns, cast times, Reap buff values, talisman boosts.

</document>

<document name="Agentic Documentation/audio-and-music.md">
# Dark Touch — Audio and Music

Part of the [Dark Touch GDD](GDD.md). Decisions only; open points are in [Open questions](open-questions.md).

## Music

- **Style:** dark neoclassical. **The cello is always the lead melody.** Mood reference: [Requiem for Wonderland by Nox Cantabile](https://www.youtube.com/watch?v=rF7QvXAZkVo).
- **No phonk for now** (designer, 2026-10-29): it will only be tested if the music lacks impact.
- **Adaptive layers:** the music changes with the situation: exploration, combat, boss.
- **Signature raise sound:** raising a soldier plays an iconic cello motif. It is a key part of the game's identity.
- **Production:** tracks are created with AI tools by the [Music Director agent](agents/music-director.md) and iterated with the designer until validated. References are mood boards only, never reused audio.

## Sound effects

- **Generated by the designer on ElevenLabs** (Sound Effects), from prompts written by the [Sound Designer agent](agents/sound-designer.md) (designer, 2026-11-07; the free sound-bank search and the Sound Board are retired). The plan used must allow commercial use.
- **Tone:** dark, grounded and weighty, necromantic and physical; nothing "too fantasy" or cheap (no sparkles, chimes, cartoon whooshes) (designer, 2026-11-07).
- **Tracker:** [review/sons.csv](../review/sons.csv) (opens in Excel) lists every needed sound with its prompt, its ElevenLabs settings, its file name and its status, from "À générer" to "Validé" (validated by the designer in the editor).
- How each action sounds and feels together with its visuals is specified by the [Game Feel Director](agents/game-feel-director.md).

</document>

<document name="Agentic Documentation/art-direction.md">
# Dark Touch — Art Direction

Part of the [Dark Touch GDD](GDD.md). Decisions only; open points are in [Open questions](open-questions.md).

## Style

Stylised, in the spirit of **Fellowship**. The world is Cel'ardor, a continent at war (see [Lore](lore.md)).

## Pipeline

1. Concept images created with GPT image generation.
2. 3D characters generated from those images with **Meshy AI**.
3. Characters rigged to the UE5 Mannequin skeleton (see below).

## Skeleton and character setup

- **Every character uses the UE5 Mannequin skeleton**, so animations are shared without retargeting.
- **The player is one skeletal mesh** on that same skeleton (designer, 2026-11-02; it used to be body + arm as two meshes). The cursed arm has its own material slot "Arm", so it still gets its own material and effects without touching the body.
- **Cloak:** only the long hanging strips are simulated cloth; the hood and the shoulder cloth follow the skin, never the simulation (designer, 2026-11-02).

### The main character

Validated concept (front and back), the reference for the 3D model:

<img src="images/main-character.png" alt="Main character concept, front and back" width="560">

- **Hood** with two small golden horns; **ornate golden mask** with glowing cyan eyes, the face lost in shadow.
- **Tattered olive-green mantle** over the shoulders, longer at the back, down to the waist.
- **Dark brown leather armour** with thin gold trims; **golden chains** across the chest and kept short and tight at the belt.
- **No long coat:** the outfit stops at the belt. Below it, only fitted leather trousers with buckled straps and wrapped leather boots, so the legs need no cloth animation.
- **Athletic build**, close to the UE5 Manny proportions, so the rig and shared animations fit with little clipping.
- **Left arm:** normal, in a dark leather glove. **Right arm:** the dark-magic arm, in **cyan-turquoise**, matching the eyes.
- Only the mantle may need light physics (one Kawaii Physics or AnimDynamics chain on its back strips).

### Enemy references

Validated mood references for four enemy types (also the soldier versions, since enemies and soldiers share the roster). They set the look; the 3D models are generated from a clean turnaround made from them. The images are third-party art kept locally for reference only (not committed).

| Type | Reference | Key traits |
| --- | --- | --- |
| Berserker | `images/references/berserker.jpg` | Bull warrior, massive black bull-headed brute (minotaur): huge horns, double-bladed axe, glowing red runes, bull skull at the belt, torn red loincloth, spiked bracers and greaves |
| Mage | `images/references/mage.jpg` | Draconic mage: blue-and-white scaled dragon head and hands, navy and cream robe with geometric trims, staff topped with a blue crystal, blue spell glow in the free hand |
| Blademaster | `images/references/blademaster.jpg` | Dark ornate plate armour, closed helm, white fur collar, tattered cloak, long two-handed greatsword stained with blood |
| Tank | `images/references/tank.jpg` | A bull warrior (like the Berserker) in the reference's armour: bull head and horns under or through the helm; heavy spiked grey plate armour, torn red cape and tabard, large shield with a red dragon emblem, sword with glowing red veins (the war banner is a prop, optional) |

For the Mannequin skeleton: keep human proportions under the look. **Bull warriors (Berserker, Tank) keep their hooves** (designer, 2026-10-29): the legs keep a human shape and human joints down to the ankle, and each ends in a large cloven hoof sitting flat under the ankle, its bottom acting as heel and sole. At skinning, the whole hoof is weighted 100% to the `foot` bone; the toe bones (`ball_l`, `ball_r`) stay in the skeleton for the shared animations but carry no weight, so the hoof stays rigid. The Mage's clawed digitigrade feet become plantigrade feet in the turnaround; horns, tails of cloth and capes are fine but kept short below the hips; weapons, shields and staffs are separate meshes attached to the hand sockets.

## The weapon: the dark-magic arm

The player fights without a blade. The right arm is not physical: it is pure dark magic, translucent and glowing **cyan-turquoise**, made of swirling spectral energy that drifts off as wisps and particles, with long clawed fingers. Although it is not flesh, it acts like a real arm: it can **strike, grab and hold things**, which is how it casts, raises and reaps.

<img src="images/arm-reference.png" alt="Reference: the spectral dark-magic arm" width="320">

*Early reference for the arm's shape and effects; its colour is now cyan-turquoise, as in the main character concept.*

It is the game's visual signature and **must stand out in every animation**: casting, raising, reaping and idle all need a distinctive effect on the arm.

## Environment assets

Level assets (rocks, trees, ruins, war camp and village props, chests, ground, sky) are stylised and slightly desaturated so characters and the cyan arm pop. They are found by the [Environment Scraper](agents/environment-scraper.md) and reviewed on the [Environment Board](https://claude.ai/artifact/5TxnhfWgdumWg5oXVUhABd).

## Readability palettes

**Enemies are warm and alive; summons are cold and spectral.** Warm against cool reads fastest, and orange against cyan stays clear for colour-blind players. Each type uses one mesh with one material: a "Raised" parameter switches it from the enemy palette to the summon palette and lights up the cyan glow.

| Enemies (living) | Hex | Summons (raised) | Hex |
| --- | --- | --- | --- |
| Tabards and cloth: burnt orange | `#C8641E` | Body and armour: slate grey | `#5E6670` |
| Secondary cloth: ivory | `#E8DCC0` | Cloth: ashen blue-grey | `#3E4650` |
| Armour: warm steel | `#9A9590` | Skin: corpse pale | `#A9B0B0` |
| Leather: tan | `#8A5A34` | Eyes, veins, cracks (emissive): the arm's cyan | `#3FE0D0` |
| Skin: warm flesh | `#C99A7A` | | |

- Summons share the player's cyan, so they read as his. The main character (dark brown, olive, gold) reads as neither.
- Elites keep the enemy palette, richer: darker, more saturated orange, heavier dark-bronze armour, bigger trims.
- Check: an enemy and a summon side by side must stay distinct in black and white.

## Rank colours

Each rank has a colour:

| Rank | Colour |
| --- | --- |
| Shadow | Pale green |
| Asset | Purple |
| Ace | Black, with a thin silver edge so it reads on dark shapes |
| General | Deep red with a black outline, kept distinct from the enemies' orange |

- **On enemies:** no effect on the body. The rank shows on the **health bar**, styled like the default modern WoW (retail) nameplate health bar, with no add-ons. **Elites** get a **gold outline** on their health bar.
- **On corpses:** a **faint aura**, weaker than on summons but still visible, so the player can scan the battlefield for good ranks. Aiming at a corpse opens a world widget above it with its name, rank and stat grades (gold outline for elites); holding **Alt** shows every health bar and corpse widget at once.
- **On summons:** the rank is an **aura**, an overlay on the skeletal mesh material plus a little smoke. It **dominates the summon palette** and is more visible than the base material.

## Elites

Any mob can be an elite: it has an aura, a slightly different colour palette, and a stat boost over the normal version. A raised elite is captured and sent to the army at the base.

</document>

<document name="Agentic Documentation/GDD.md">
# Dark Touch — Game Design Document

Other versions: [Full reference GDD](GDD-full.md) (every rule in detail) · [Canon](canon.md) (for the AI agents)

Companion documents: [Art direction](art-direction.md) · [Audio and music](audio-and-music.md) · [Lore](lore.md) · [Open questions](open-questions.md)

## 1. Executive Summary

**Dark Touch is a roguelike where a spectral dark-magic arm raises fallen enemies into your army, played with WoW-style GCD and rotation combat using aimed abilities.** A one-armed half-dragonkin who had never cast a spell made a pact with a dark entity; the cursed arm it gave him casts on its own and turns every kill into a potential soldier. Every corpse is a choice: raise it to grow the army, or reap it to fuel your spells. Hidden stat grades and ranks turn army building into a hunt for the perfect soldier.

| | |
| --- | --- |
| Genre | Roguelike with army building and aimed, rotation-based combat |
| Engine | Unreal Engine 5.8. All gameplay code in C++, written by the agents; Blueprints only assign assets |
| Camera | Directly behind and above the player, WoW-style, with zoom in and out |
| Platform | PC, mouse and keyboard; controller may come later, so nothing should block it |
| World and art | Cel'ardor, a continent at war ([Lore](lore.md)); stylised, in the spirit of Fellowship ([Art direction](art-direction.md)) |
| Music | Dark neoclassical, cello-led, adaptive to combat ([Audio and music](audio-and-music.md)) |
| Inspirations | Solo Leveling (raising soldiers), World of Warcraft and Fellowship (ability-bar combat), Diablo 4 (ability variants), Mythic+ (difficulty tiers) |
| Demo scope | One level of 5 sections ending with a boss; 7 spells at the start, 5 more by player level |
| Production | Built over 7 weeks for the ELVTR multi-agent AI course by one designer and a team of 13 AI agents, each gated by the designer's approval. The scope is knowingly ambitious: Dark Touch is the game I have always wanted to make, and I am ready to keep finishing and polishing it for a month or more after the course if needed |

## 2. Game Mechanics

### Core loop

**Fight, kill, then decide what each corpse becomes.** Raising costs time and positioning but grows the army; reaping is instant and fuels your spenders. Across a run, the army you build and the Souls you gather carry you to the boss.

![Core loop: fight, enemy dies, Raise or Reap](images/core-loop.svg)

### Combat

**Combat plays like a WoW ability bar, but every ability is aimed by the player.**

- Abilities are instant or have a cast time; a **1-second global cooldown** applies to every spell except Reap. No casting while moving, except Splinters, Grasp, Frenzy, Hunger and Rot.
- Taking a hit does not interrupt a cast: it **pushes the cast back by 1.5 s**. Only stuns interrupt, such as the Mage's charged spell or the Blademaster's parry.
- **No dodge:** enemy windups, like the Blademaster's parry, are answered by stopping the cast and moving away.
- Fillers build Souls; spenders consume them. **Damage is always rounded down to a whole number.**
- **Controls:** rebindable. Defaults A, E, R, F, 1–5 and Shift + the same: 18 slots for the 12 spells, 3 golden-slot abilities and 3 command-group keys.

| Resource | Role | Gained by | Spent on |
| --- | --- | --- | --- |
| Spirit | Army resource, max 100 + 20 per level, no regen | 50 per section, 5 per Reap | Raise 20–180 by rank and grades, revive 60% of the raise cost |
| HP | No regen over time | Hunger; Reap for HP (2 s cast, 20%) | Damage taken |
| Souls | Short loop, Soul Shard-style; max 6 | Deathbolt (1), Splinters (1, 2 with a proc) | Spenders, 3 each |

There is no currency.

| Ability | Role | Aiming |
| --- | --- | --- |
| Deathbolt | 1.75 s cast filler, last priority | Aimed |
| Unholy Impale | Single-target spender, 2 s cast | Aimed |
| Splinters | Instant AoE, 2 charges (5 s each), builds Souls | 30° cone, 40 m, from a narrow base |
| Raw Nova | AoE spender, 2 s cast | Ground circle |
| Grasp | Root | Ground circle |
| Swap | Swap places with a soldier | Aimed |
| Frenzy | Timed buff on soldiers | All soldiers |
| Hunger | Instant, 10 s cooldown: eats one of your soldiers (not Chosen), healing you by its HP (capped at 30–60% of your max HP by its rank); it becomes a corpse again | Aimed |
| Rot | Instant hitscan curse, on several enemies: damage every 1 s for 10 s; no Souls | Aimed |
| Power of Below | Offensive cooldown, 15 s, every 120 s: GCD 0.75 s, casts halved, spenders instant, Splinters 3 s | Self |
| Raise | Turn a corpse into a soldier | Aimed |
| Reap | A 10 s buff, plus 5 Spirit (left click) or 20% HP over a 2 s cast (right click) | Aimed |

Names are final. Grasp, Swap, Frenzy, Rot and Power of Below are unlocked by player level. Each ability has **two unlockable variants** (Diablo 4-style); Reap has three: HP regen, damage or speed. Soft-targeting assist vs raw aim is decided during prototyping.

### Rotation

**Fillers build Souls, spenders consume them.** Souls cap at 6; each spender costs 3. Deathbolt gives 1 Soul, Splinters 1 (2 with a proc), Rot none. Base rotation without talismans, single target (in AoE, Raw Nova replaces Unholy Impale):

| Priority | Ability | When |
| --- | --- | --- |
| 1 | Unholy Impale / Raw Nova | Souls capped: always spend, never overcap |
| 2 | Splinters with a proc | Souls not capped: a proc beats the spender |
| 3 | Unholy Impale / Raw Nova | Whenever Souls allow it |
| 4 | Rot | On the main enemy, if it is not cursed (a recast refreshes it to 10 s) |
| 5 | Splinters | Whenever a charge is ready (2 charges, 5 s each) |
| 6 | Deathbolt | 1.75 s cast filler, when nothing else is ready |

- **Splinters proc:** every player hit except Splinters' own has a **10% chance** to give a free Splinters charge and **double its next hit**. Up to 2 procs are held (both charges empowered); a third is lost. Rot's first hit rolls 10%, its later ticks 1%. Soldiers' hits never proc.
- **Free spender proc:** each enemy hit by Splinters has a **5% chance** to make the next spender cost no Souls; only one is stored. AoE taking over the rotation most of the time is intended.
- **Power of Below**, the offensive cooldown: GCD 0.75 s, cast times halved, spenders instant and castable while moving, Splinters charges every 3 s.

### Necromancy and the army

**Every corpse is a choice: Raise it into a soldier, or Reap it for power.**

- **Raise:** costs Spirit by rank (Shadow 50 to General 150), +10 per S grade, −10 per B grade. Cast time, and the player must be close to the corpse, so raising mid-fight is a skill check. Each soldier takes a slot; **10 slots** max at endgame.
- **Reap:** a 10-second buff, plus a choice by mouse: left click for 5 Spirit (instant), right click for 20% of max HP (2 s cast). No Souls.
- **Behaviour:** with no orders, soldiers attack the first enemy they see. Soldiers are dragged into **3 command groups**; a group's key swaps the bar to its orders, **Attack**, **Protect** (hit the biggest threat to the player) and **Move**. **3 golden slots** give their soldier's type ability to the player as a spell.

| Type | Behaviour | Targeting | Player ability |
| --- | --- | --- | --- |
| Guard | Sword-and-shield footman; sometimes shields up, standing and turning slowly | None | **Guard:** damage reduction for 1.5 s |
| Mage | Ranged arcane bolts; occasional long charged spell for massive damage that stuns | Biggest threat to it | TBD |
| Rogue | Dual blades, fast, high damage, squishier; 1 s windup, then dashes through normal mobs | Player and elites first | TBD |
| Tank | Bull warrior, armoured, slow, hits hard, very tough; cannot be stunned | None | **Taunt:** all nearby enemies focus the Tank, Rogues included |
| Blademaster | Two-handed elite class: sturdy, hard-hitting, fairly fast; occasional parry with a visible windup, sending damage back and stunning | None | **Parry:** sends an attack back at 2x damage |
| Berserker | Bull warrior; leaps onto its target; Whirlwind, a quick AoE around itself; cannot be stunned | TBD | TBD |

**Elites: a capture system.** Any mob can be an elite: a richer palette, a gold outline on its health bar, and a stat boost. A raised elite is captured, Pokémon-style, and sent to the collection at the base, the menu between runs where the player picks soldiers, talismans and difficulty. Every fallen elite can be captured, with no limit; it keeps its elite status and stats, but is **lost if the player loses the run**. A special capture, possibly a rhythm mini-game, is planned for later.

**Hunting for the right soldier.** Every mob has a random name. Alive, all mobs of a type share the same stats; each mob's **rank** shows on its health bar, and aiming at a corpse opens a widget above it with its rank and hidden **grades** (holding **Alt** shows every health bar and corpse widget):

- **Grades**, one per stat: Vitality (max HP), Attack (damage), Speed (cast speed for ranged, movement speed for melee). S = 1.25x, A = 1x, B = 0.75x.
- **Rank**, inspired by Solo Leveling: Shadow (1), Asset (2), Ace (3), General (4). Rank boosts every stat without changing grades; a better rank almost always means a better soldier, by design. Tiers are endless (20 = top end game); Generals appear from tier 14. Each rank has a colour: shown on enemies' health bars, as a faint aura on corpses, and as a strong aura on soldiers.
- **Effective stat = (Base × Grade) × (1 + (Rank − 1) × 0.5)**: Shadow 1x, Asset 1.5x, Ace 2x, General 2.5x. Higher difficulty tiers give better grade odds.

### Run structure and progression

| Element | Decision |
| --- | --- |
| Levels | Demo: one level ending with a boss. Later: 3 medium levels, each ending with an elite or boss, 20–25 minutes |
| Layout | Outdoors for now, split into 5 sections of about 5 fights, cleared in order with no going back. Leaving a section is a decision point for the army |
| Win / lose | Kill the final boss / player HP reaches 0 |
| Difficulty | Endless Mythic+-style tiers (20 = end game): stronger mobs, more enemies and higher ranks (General from tier 14), better grade odds |

| What | Rule | Win | Death |
| --- | --- | --- | --- |
| Collection | Soldiers raised and won with, plus captured elites | Grows | This run's raises and captures lost |
| Chosen | 0 to 3 soldiers brought from the collection, by player level; the rest is raised in the run | Kept | Kept |
| Talismans | Only gear. Found in hidden chests or dropped by foes; 2 equipped before a run, each boosting one spell; aim: 2–3 new per completed run | To define | To define |
| Player level | Max 15; levels 2–15 unlock 5 spells, 6 variant slots and 3 Chosen slots ([Level Unlocks board](https://claude.ai/artifact/NqX8sL4fDcjPXyauHew4vz)) | Kept | Kept |
| Talents | Passive; some change how Souls are gained | Kept | Kept |

**Fallen soldiers.** Any fallen soldier can be revived, even mid-fight by casting Raise on it, for 60% of that soldier's raise cost (12 for a weak Shadow, 108 for an S-grade General). A raised soldier that falls and is not revived before the player leaves the current section is lost for the run; Chosen stay in the collection. Before moving on, the player must choose which fallen soldiers are worth the Spirit. When a run ends, the whole collection is ready again.

## 3. AI Architecture

**Each agent shapes a part of what the player sees, hears and fights; none of them ships anything without the designer's approval.**

| Agent | Its effect on gameplay |
| --- | --- |
| Gameplay Programmer | Every rule in this document becomes a working system the player can feel: aimed casting with the 1.5 s pushback, Raise and Reap, army slots and command groups, grades and ranks, talismans and progression. |
| AI Director | Every enemy and soldier fights with its own readable personality: Rogues dash at the player, Tanks pull aggro with Taunt, Blademasters telegraph their parry. One behaviour per type serves both sides, so a creature you fought plays the same way once raised. |
| Game Feel Director | Every ability, hit, raise and button press has its own feel through hit-stop, camera shake, sound and UI feedback; fillers stay light, spenders hit hard, and raising a soldier is the signature moment. |
| Animation Scraper | Every action and ability has a validated animation on the shared UE5 Manny skeleton, so soldiers and enemies move consistently and the cursed arm stays readable. |
| Environment Scraper | The level is built from coherent, stylised assets that frame each arena and keep characters readable from the camera. |
| Producer | The demo that ships is the one that plays best: a cut list, weekly playable milestones and decisions taken on time keep the core loop polished by week 7. |
| Level Designer | Every fight, section and the boss are built to be read and learned: the first section teaches the kit one piece at a time, and the boss's adds switch the rotation between single target and AoE. |
| Balance Analyst | Every number is simulated before it is built, so the Spirit economy, procs and healing stay a real choice at tier 1 and at tier 20. |
| UI Designer | The HUD makes the rules visible: the cast bar shows the 1.5 s pushback, the army panel shows names, grades and ranks, and command groups are a drag away. |
| Music Director | The cello-led score shifts between exploration, combat and boss layers, and every raise triggers the same iconic motif. |
| Sound Designer | Every ability and hit gets a distinct sound effect, so the player can read the fight by ear. |
| Technical Director | A full army of 10 soldiers plus enemies keeps a stable frame rate, and systems like casting, raising and slots never conflict. |
| Game Director | Everything above stays consistent with the GDD and with itself: one art style, one audio identity, one set of rules. |

**Review flow:** the Producer plans the week; the Balance Analyst checks the numbers before a build; a builder agent finishes a task → the Technical Director checks that it works → the Game Director checks that it fits the game → the designer validates. Validated facts go into [canon.md](canon.md), which every agent reads first.

## 4. Technical Strategy

### Agent roles

| Agent | Model | What it does | Prompt | Tools and cost |
| --- | --- | --- | --- | --- |
| Gameplay Programmer | Claude Opus 5.5 | Builds the game's systems (abilities, casting, raising, army, grades, progression). For each one, explains how it will build it and waits for your validation; then builds it, you test it, and it iterates until you validate. | [Open prompt](agents/gameplay-programmer.md) UE5 MCP and the build scripts; builds, tests and fixes its own code before hand-over. About 20–40k tokens per explanation (roughly $0.15–0.29) and 40–80k per build (roughly $0.29–0.58). |
| Game Director | Claude Opus 5.5 | Called at the end of every meaningful task. Checks the work against the GDD and against existing assets for consistency, then gives a verdict: approved, approved with notes, or changes required. Reviews only; you keep the final word. | [Open prompt](agents/game-director.md) | No external tools. About 10–20k tokens per review, roughly $0.07–0.15 per review. |
| Technical Director | Claude Opus 5.5 | Keeps the map of every system (systems.md). Checks that systems' inputs and outputs fit together, that each piece of data has one owner, and that systems stay loosely coupled. Reviews performance (army AI, Event Tick, arm effects, spawning) and proposes streamlining that keeps the polish. Reviews before the Game Director. | [Open prompt](agents/technical-director.md) | Unreal MCP and the build scripts; Unreal Insights captures. About 15–30k tokens per review, roughly $0.11–0.22 per review. |
| Game Feel Director | Claude Sonnet 5.5 | Gives every ability, hit, raise, button press and drag-and-drop its own distinct, polished feel: anticipation, impact, follow-through, camera shake, hit-stop, sound, UI feedback and the arm's effect. Writes a feel spec per interaction and reviews recordings with your 1–5 ratings. | [Open prompt](agents/game-feel-director.md) | No external tools required; reviews GIFs or short videos you record. About 5–10k tokens per spec (roughly $0.02–0.04) and 10–20k per review (roughly $0.04–0.07). |
| UI Designer | TBD | Designs one screen at a time, most important first (in-game HUD, army tab, builds tab, main menu…). Shows 4 mockups per screen, each with a different design intention, then iterates until you validate. Validated screens set the visual language for the next ones. | [Open prompt](agents/ui-designer.md) | HTML mockups at 1920x1080; optional image generation for style frames. About 20–40k tokens per round of 4 mockups; cost TBD with the model. |
| Music Director | Claude Sonnet 5.5 | Creates the music with AI tools: 3 tracks per round, waits for your feedback, iterates until you validate. Also makes the cello raise motif. | [Open prompt](agents/music-director.md) | ElevenLabs Music API, about $0.15 per minute (paid plan from $6/month); Stable Audio about $0.20 per generation; Suno free for exploration. About 5–8k tokens per round, roughly $0.02–0.03; a round of 3 two-minute tracks is about $0.90 in generation. |
| Sound Designer | Claude Haiku 5.5 | Writes an ElevenLabs prompt (with its duration and prompt-influence settings) for every sound the game needs; you generate the sounds yourself. Keeps the sound tracker (review/sons.csv): missing, generated, imported, wired, validated in the editor. | [Open prompt](agents/sound-designer.md) | ElevenLabs (your account, a plan that allows commercial use). About 2–5k tokens per batch of prompts, under $0.01. |
| AI Director | Claude Opus 5.5 | Owns the behaviour logic of every enemy and soldier, one shared version per type. Builds basic logic first; before each upgrade, presents how it will build it, what it costs and which details it recommends, discusses with you, and implements only once you confirm. | [Open prompt](agents/ai-director.md) | UE5 MCP. About 20–40k tokens per proposal round (roughly $0.15–0.29) and 40–80k per implemented stage (roughly $0.29–0.58). |
| Animation Scraper | Claude Sonnet 5.5 | Finds 2 candidate animations per action and ability, Manny-skeleton first (Fab, Mixamo and others), for you to validate or reject. Then downloads the validated ones, or gives you the link when it needs your account, and retargets them to the UE5 Manny skeleton. | [Open prompt](agents/animation-scraper.md) | UE5 MCP; Mixamo free with an Adobe account, Fab free to paid (you approve purchases). About 5–10k tokens per animation, roughly $0.02–0.04. |
| Environment Scraper | Claude Sonnet 5.5 | Finds 3 stylised candidates per level asset (Fab, Kenney, Quaternius, Sketchfab, Poly Haven) with licence, price and triangle count, and posts them to the Environment Board. Imports the picked ones into a reusable environment library. | [Open prompt](agents/environment-scraper.md) | UE5 MCP; free sources, Fab paid packs only if you approve. About 5–10k tokens per asset, roughly $0.02–0.04. |
| Producer | Claude Sonnet 5.5 | Writes the demo cut list (in the demo / after the course), weekly playable milestones and a decide-by week for every open question; tracks Claude Pro usage and the designer's review load against the plan. | [Open prompt](agents/producer.md) | No external tools. About 10–20k tokens per weekly update, roughly $0.04–0.07. |
| Level Designer | Claude Opus 5.5 | Designs the 5 sections, each fight's enemy mix, exits, chests, the boss and the first-run onboarding; proposes one section at a time, then builds a blockout and iterates after your playtest. | [Open prompt](agents/level-designer.md) | UE5 MCP; reads the Rank Odds board. About 20–40k tokens per proposal (roughly $0.15–0.29) and 40–80k per blockout (roughly $0.29–0.58). |
| Balance Analyst | Claude Sonnet 5.5 | Reads the tuning boards and the canon, runs Python simulations of runs, procs and healing at tiers 1, 10 and 20, and reports problems with options before anything is built; re-checks when a number changes. | [Open prompt](agents/balance-analyst.md) | Python in Claude Code; reads the boards. About 10–20k tokens per analysis, roughly $0.04–0.07. |

**Review boards:** the [Environment Board](https://claude.ai/artifact/5TxnhfWgdumWg5oXVUhABd) lists every needed level asset with 3 candidates: pick one, or ask for 3 more. Sounds are tracked in [review/sons.csv](../review/sons.csv) (the Sound Board is retired, 2026-11-07).

### Token budget

**The agents run on a Claude Pro subscription: $20 per month, about $40 for the 7-week course.** Claude Code is included, and its usage shares the same limits as claude.ai: a limit that resets every five hours, plus a weekly limit. Opus agents use those limits faster than Sonnet or Haiku, so the heaviest work is spread across sessions; usage credits can be enabled if a limit blocks a deadline. The per-use costs in the table above are API-equivalent figures, for reference.

| Agent | Model | Assumed workload over 7 weeks | Tokens |
| --- | --- | --- | --- |
| Gameplay Programmer | Opus 5.5 | ~15 systems, each explained, built and fixed twice | ~1.8M |
| Game Director | Opus 5.5 | 60 reviews | ~0.9M |
| Technical Director | Opus 5.5 | 40 reviews | ~0.9M |
| AI Director | Opus 5.5 | 6 proposal rounds, 4 implemented stages | ~0.4M |
| Game Feel Director | Sonnet 5.5 | 15 specs, 20 reviews | ~0.4M |
| UI Designer | TBD | 8 screens × 3 rounds | ~0.7M |
| Animation Scraper | Sonnet 5.5 | 40 animations | ~0.3M |
| Environment Scraper | Sonnet 5.5 | 40 assets | ~0.3M |
| Producer | Sonnet 5.5 | 7 weekly plans and updates | ~0.15M |
| Level Designer | Opus 5.5 | 5 sections, the boss and onboarding | ~0.35M |
| Balance Analyst | Sonnet 5.5 | 10 analyses | ~0.15M |
| Music Director | Sonnet 5.5 | 10 rounds | ~0.1M |
| Sound Designer | Haiku 5.5 | 30 sounds × 2 rounds | ~0.4M |
| **Total** | | | **~7M** |

**Outside the subscription:** about $10 of music generation, plus ElevenLabs from $6 per month. API-equivalent value of the tokens, without the UI Designer: about $37.

### How the agents run (proposed setup, to confirm in week 1)

**Claude Code** (included in Pro) runs each agent as a subagent with its [prompt](agents/) and model; the main session routes each task to an agent, then to the reviewers. Shared memory lives in versioned files (canon.md, systems.md, feel.md, animations.md, reviews.md); every gate is the designer. **Everything is built to be reused** in a future project: generic, data-driven systems with a README each. Details in the [full reference GDD](GDD-full.md).

</document>

Review this generated content for Dark Touch (target: section1). It is a proposal for the designer.
<output>
{
 "section": 1,
 "tier": 1,
 "layout_areas": [
  "The Waking Yard (start, no fight): the walled back yard of the last house of the small town, about 20 x 20 m. The half-dragonkin wakes here with the pact arm glowing cyan-turquoise. The only way out is a north gate facing the enemy army's camp smoke.",
  "The Stakeline Furrows (fight 1): a harvested field, 25 m wide and 110 m long, with the enemy army's forward stakes and burnt-orange pennants. Its long straight sightline lets the arm's first bolts land before anything reaches the player.",
  "The Headstone Road (fight 2): the army's road, 20 m wide and 70 m long, paved with gravestones taken from the town's burial ground. Fight 1's corpses lie at its south end, away from any enemy.",
  "The Robbed Graves (fight 3): the town's burial ground dug open for road stone, entered from the south through a 12 m wide sunken lane about 45 m long. A half-loaded stone cart stands at the lane's north mouth. Waist-high broken grave walls make a corpse pocket on the east side.",
  "The Ash Meadow (fight 4): a flat hay meadow, about 50 x 60 m, burned black by the army so the town has no harvest left. Nothing taller than ankle height stands here, and warm enemy colours stand out against the ash.",
  "The Slabwrights' Camp (fight 5): the army work camp where gravestones are cut into bridge slabs, an open yard about 40 x 40 m ringed by low slab stacks, with a corpse pocket behind the south stacks.",
  "The Slab Bridge (exit): a bridge of laid gravestones over a ravine on the north edge of the camp, the road by which the enemy army would reach the town."
 ],
 "fights": [
  {
   "id": 1,
   "area": "The Stakeline Furrows",
   "enemies": [
    {
     "type": "Guard",
     "count": 2,
     "rank": "Shadow"
    }
   ],
   "placement": "Guard A stands on the centre line 50 m north of the entrance. Guard B stands 35 m beyond Guard A, offset 5 m to the side and past the 20 m notice radius, so the player fights one at a time. The board's minimum of 2 is met without two swords on the player at once.",
   "teaches": "Deathbolt alone: aim with the centre crosshair, stand still, and see that moving cancels the cast and that each hit gives 1 Soul. When Guard A arrives, its hits teach pushback. Afterwards the two corpses are left lying for the next lesson.",
   "spells_needed": [
    "Deathbolt"
   ],
   "readability": "Guard A must be centred at the crosshair on arrival, with its health bar just in range at 50 m. The Deathbolt flight, the Guard's whole walk in, the sword swing and the player's cast bar reacting must all read from the default 200 cm camera, with no tall props on the centre line."
  },
  {
   "id": 2,
   "area": "The Headstone Road",
   "enemies": [
    {
     "type": "Guard",
     "count": 2,
     "rank": "Shadow"
    }
   ],
   "placement": "Before the fight, Fight 1's two corpses lie 10 m south of the first enemy's 20 m notice radius, so Raise is cast in safety. Guard A stands on the road centre 40 m north of the corpses. Guard B stands 12 m behind it and 6 m left, so the soldier takes the first Guard and the second comes to the player alone.",
   "teaches": "First, Raise: a corpse becomes a soldier, and the 50 Spirit from entering the section pays for it. Then the soldier's behaviour, as it attacks the first enemy it sees. Then Unholy Impale: spend the 3 or more Souls built in fight 1, cast in the gap before Guard B reaches the player.",
   "spells_needed": [
    "Raise",
    "Unholy Impale",
    "Deathbolt"
   ],
   "readability": "The corpse widget (name, rank, three grades) must be readable when aimed at. The Raise levitation must play in clear ground. Both Guards must stay in the forward view with the soldier visibly peeling off to Guard A, and the Impale spear must read flying into Guard B."
  },
  {
   "id": 3,
   "area": "The Robbed Graves",
   "enemies": [
    {
     "type": "Guard",
     "count": 3,
     "rank": "Shadow"
    }
   ],
   "placement": "Three Guards stand shoulder to shoulder within 4 m of each other at the stone cart, at the north mouth of the sunken lane. The player sees them from the south end of the lane, 35 to 38 m away, inside Splinters' 40 m cone and outside the 20 m notice radius. If pulled, they must funnel down the 12 m lane and stay bunched.",
   "teaches": "Splinters: one instant cone hits the whole pack and gives 1 Soul per cast. Then Raw Nova as its payoff: enough Souls from Splinters and one Deathbolt let the 2 s ground circle land on the bunched pack before it arrives. Afterwards, Reap on the three corpses by the east grave walls: left click for 5 Spirit, right click for 20% HP.",
   "spells_needed": [
    "Splinters",
    "Deathbolt",
    "Raw Nova",
    "Reap"
   ],
   "readability": "All three Guards must fit inside the visible cone from the lane mouth, and the Raw Nova circle must be readable on bare earth while it follows the aim. The lane walls stay below the camera line. The Reap left/right-click choice must be visible at the corpses."
  },
  {
   "id": 4,
   "area": "The Ash Meadow",
   "enemies": [
    {
     "type": "Guard",
     "count": 1,
     "rank": "Shadow"
    },
    {
     "type": "Rogue",
     "count": 1,
     "rank": "Shadow"
    }
   ],
   "placement": "The Guard stands 30 m ahead and 12 m to the east, the first target the soldier sees. The Rogue stands 25 m straight ahead on the centre line, with at least 15 m of clear ash on each side of the player's approach for sidestepping.",
   "teaches": "A windup is answered by stopping the cast and moving away. The Rogue's 1 s windup comes straight down the crosshair, and stepping aside cancels the cast but avoids the dash. The dash also goes through soldiers, so an army is not a wall and the Rogue goes for the player.",
   "spells_needed": [
    "Deathbolt",
    "Splinters",
    "Unholy Impale"
   ],
   "readability": "The Rogue's 1 s windup must be fully visible and centred against black ash, with the dash line clear from the default camera. The Guard and soldier fight stays off to the east so it does not cover the Rogue."
  },
  {
   "id": 5,
   "area": "The Slabwrights' Camp",
   "enemies": [
    {
     "type": "Guard",
     "count": 2,
     "rank": "Shadow"
    },
    {
     "type": "Rogue",
     "count": 1,
     "rank": "Shadow"
    }
   ],
   "placement": "Two Guards stand 25 m ahead, 8 m apart, either side of the centre line and arriving together. The Rogue stands 30 m ahead, centred behind them, so it dashes at the player through the Guards. Fight 4's corpses are not in reach, but the first Guard killed drops near the south stacks and that pocket stays open to the player.",
   "teaches": "Hunger: under two or more attackers a 2 s Reap for HP can be pushed back endlessly, while Hunger is instant, usable on the move, and heals up to 300 HP from a Shadow soldier. Its eaten soldier becomes a corpse again, which sets up the exit decision.",
   "spells_needed": [
    "Hunger",
    "Splinters",
    "Raw Nova",
    "Unholy Impale",
    "Reap"
   ],
   "readability": "The player's own soldier must stay easy to aim at inside the crowd: cold slate and cyan against the warm enemy palette, on open floor. The player's HP bar, the Rogue's windup between the Guards and the fang effect on the eaten soldier must all read in the forward view, with slab stacks kept low."
  }
 ],
 "exit": "The Slab Bridge, once fight 5 is cleared. Crossing the marked first slab opens a confirmation that lists each fallen soldier and its revive cost, so the no-going-back rule is stated before it costs anything. When the player crosses, the arm wrenches the gravestones loose behind him and the bridge falls into the ravine. The army's road to the town is cut, and the player cannot return.",
 "chests": [
  {
   "area": "The Stakeline Furrows",
   "why": "Behind a collapsed stake pile at the east edge, about 40 m from the centre line and beyond the fight 1 path. It rewards a player who looks away from the obvious sightline, is safe to reach after the fight, and shows early that hidden chests exist."
  },
  {
   "area": "The Robbed Graves",
   "why": "Inside an opened grave behind the east walls, reachable only by walking past the Reap pocket. The place belongs to this level's story, and the player is already drawn there by the corpses, so noticing it rewards attention without any risk during a fight."
  }
 ],
 "assumptions": [
  "Enemy counts are authored inside the board's 2-3 range so that each lesson holds, for 12 enemies total, whereas canon says the number is rolled per fight. If the roll must stay live, a roll of 2 removes the rearmost enemy of a 3-enemy fight and a roll of 3 adds one rear Guard beyond notice range in a 2-enemy fight. Designer to confirm.",
  "The role text's example of a first fight with one enemy conflicts with the board's minimum of 2, and the board wins. Fight 1 uses 2 Guards staggered beyond notice range. This requires that a Guard does not alert others when it notices or is shot (AI Director to confirm).",
  "All enemies are Shadow as per the board, with grades rolled 5% S, 60% A, 35% B. I placed no elites, since the board gives no elite odds and the roster's elite frequency is open.",
  "Enemy types are limited to Guards and Rogues. Mage, Blademaster, Tank and Berserker are left to later sections so that stuns and parry are not introduced during onboarding. The final level roster remains open.",
  "Only the Guard has a combat block in canon. Rogue HP, damage, dash length, dash damage and whether a sidestep fully avoids the dash are undefined; I assume a sidestep avoids it, following the 'stop the cast and move away' rule. Fights 4 and 5 cannot be tuned until these exist.",
  "What marks the exit (bridge, collapse, confirmation list, gated on clearing fight 5) is my proposal for an open question. The confirmation list needs UI Designer work.",
  "Chest positions and the number of spots are my proposal. Whether a spot actually holds a talisman must stay subject to the open drop rate, since a filled chest in every spot across 5 sections would overshoot the target of 2-3 new talismans per run.",
  "The run's starting Spirit is not stated. I assume 0 before section entry, so the player has 50 on entering section 1. About 94% of Shadow corpses cost 50 or less, so at least one of fight 1's two corpses is affordable about 99.6% of the time.",
  "Spirit estimate for the Balance Analyst: average Shadow raise cost is about 41. With 12 corpses, 50 Spirit plus 5 per Reap funds 2 raises reliably, and 3 only with cheap B-grade corpses, at the low end of the 2-3 target. The second average raise becomes affordable around the end of fight 4 if every other corpse is reaped for Spirit, which competes with reaping for HP.",
  "Raise cast time and range, and Splinters, Unholy Impale, Raw Nova and Soldier damage values are undefined. Raw Nova's range and radius are also undefined; fight 3 assumes it can reach the pack as it comes down the lane.",
  "I assume Souls persist between fights, since nothing says they reset. Fight 2's Impale lesson relies on this; otherwise three Deathbolts are needed first.",
  "Each new spell needs a brief non-blocking prompt or action-bar highlight the first time its situation occurs, which is the only instruction beyond the staging. This is a request to the UI Designer and does not count as a separate tutorial; designer to confirm.",
  "Guard speed is taken as 640 cm/s because canon gives the Guard 'the player's walking speed' but defines only a 640 cm/s run. A slower walk makes the openings safer. All layout distances are blockout values to test in play.",
  "Numbers warning for the Balance Analyst, with Deathbolt at canon's 1.5 s (GDD.md's 1.75 s is out of date), 60 damage against a 500 HP Guard: an A-Vitality Guard takes 9 bolts, about 5 before contact from 50 m and about one per swing after, so fight 1 with Deathbolt alone costs about 320 of 1000 HP.",
  "Pushback warning: two Guards in melee with swings offset by 1.0 to 1.5 s never leave a 1.5 s gap, so Deathbolt can never complete. Raw Nova's 2 s cast is locked even sooner. Fights 3 and 5 therefore rely on opening at range, on soldiers and on instant spells. Canon's wording 'pushed back down to 0 s remaining' is ambiguous, but the lock holds under either reading.",
  "Fight 5 can pressure the player toward Hunger but cannot force it, and Hunger needs a living soldier. A player without one falls back on reviving a fallen soldier if Spirit allows or on Reap for HP in the south pocket. Whether that fallback is enough needs playtesting."
 ]
}
</output>

The automatic rule check reported: no failure
Do not repeat those failures as issues.
