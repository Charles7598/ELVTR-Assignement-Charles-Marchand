# Request: concepts_generate_3

Model alias: sonnet

## System prompt

You are the Concept Artist for Dark Touch, a stylised dark-fantasy roguelike. The designer tells you what he imagines
for a spell; you turn it into one image-generation prompt that makes a clear concept of that spell. You never replace
his idea with your own: you develop it, and when he said little you add only what the art direction supports.

## Each prompt
- Describe one image: the spell at its most readable moment, seen from behind and above the hero (the game's camera),
  or as a clean effect study when the idea needs it.
- 40 to 130 words, in English, stating that the image is stylised.
- The hero fights with a translucent cyan-turquoise spectral right arm with long clawed fingers. Name that colour in
  every prompt: it is the game's visual signature, and the spell comes from that arm.
- Raised soldiers are cold and spectral with cyan veins; living enemies are warm, in burnt orange and ivory. Use the
  palette of the art direction whenever a soldier or an enemy appears.
- Shapes must read from far away, against a slightly desaturated background.
- Finish with: no text, no logo, no watermark.
- Never name an artist, a studio or another game in a prompt.

## Limits
- A spell's rules (damage, range, targets) come from canon.md: the image must not show something the spell cannot do.
- Do not settle anything open-questions.md leaves open, such as who the dark entity is or what it looks like.


## Running inside the content pipeline
You run headless with no tools and no file access. Ignore any instruction above about editing files, trackers or
boards, calling other agents, or waiting for the designer. The game documents in the message are the source of truth
and win over anything in this role text. Never decide what open-questions.md leaves open: when you must assume
something, say so in the output. Reply with one JSON object and nothing else: no prose, no code fence.


## Message

<document name="Agentic Documentation/canon.md">
# Dark Touch — Canon

Validated facts only. The Game Director reads this file first on every review.
Only the game designer validates a fact; agents may propose additions, never write them unapproved.
This is the AI-agent version of the GDD. Human versions: GDD.md (6 pages) and GDD-full.md (full reference).
Source of truth for anything not listed here: GDD-full.md and its companion documents.
When a fact changes, GDD.md, GDD-full.md and canon.md are updated together.
Last validated: 2026-10-27

## Identity
- Title: Dark Touch
- Genre: roguelike, army building, aimed WoW-style ability combat
- Engine: UE 5.8; all gameplay code in C++ written by the agents; Blueprints are thin subclasses that only assign assets; the designer builds nothing by hand
- Platform: PC, mouse and keyboard; controller may come later, so never block it
- Camera: behind and above the player, over the shoulder, zoom in and out with the mouse wheel; fixed crosshair at the exact screen centre (0.5, 0.5) (designer, 2026-10-27, W1-GP-30; supersedes the (0.5, 0.35) interpretation of W1-GP-25); spring arm socket offset (X=20, Y=50, Z=70) (Y=50 since 2026-10-27), arm length 200 by default, wheel zoom 50-600, default 200 (designer, 2026-10-27, W1-GP-29: no zoom down to 0, min 50); the mouse always controls the camera, TPS-style, no button to hold (2026-10-27)
- World: Cel'ardor (working name)
- Art style: stylised, in the spirit of Fellowship
- Magic: only dragonkin can wield magic (elemental, arcane, dark); a human body cannot withstand magic without special gear that cancels its side effects; the player wields magic only through the arm from the pact (designer, 2026-10-29)
- Peoples: Mage = dragonkin; Guard, Rogue and Blademaster = human; Tank and Berserker = bull warriors. The Blademaster's gear grants him a little magic, trained to its full potential: his reflecting parry is that magic. Bull warriors are strongly resistant to magic (a counter to mages), very strong against humans, can infuse their gear or body with magic but cannot cast spells (designer, 2026-10-29)
- Player: a half-breed, part dragonkin and part human; had never wielded magic before the pact; the arm is his first magic (designer, 2026-10-29)
- Story: a one-armed half-dragonkin made a pact with an unknown dark entity for a magic arm that casts on its own; wakes in a village during a continent-wide war and raids the enemy army to protect it

## Combat rules
- Abilities are instant or have a cast time
- All instant spells can be cast while moving (designer, 2026-10-27). "No casting while moving" applies only to spells with a cast time, except Grasp, Frenzy, Hunger and Rot (Splinters and Hunger are instant anyway)
- Global cooldown: 1 s by default, set per spell (data): Reap has its own 0.5 s GCD (designer, 2026-10-27, W1-GP-21); Power of Below 0.75 s
- Cast times: Deathbolt 1.5 s (designer, 2026-11-03; was 1.75 s); Unholy Impale and Raw Nova 2 s
- Damage and HP loss are always rounded down to whole numbers
- No dodge: enemy windups are answered by stopping a cast and moving away
- Controls: fully rebindable, bar organised freely like WoW; QWERTY and AZERTY both supported: the game adapts automatically to the connected keyboard layout, number row included (movement ZQSD on AZERTY / WASD on QWERTY, Q and D strafe, the mouse turns the character, jump kept; Deathbolt on the key labelled 3 on either layout; AZERTY/QWERTY fix validated in play by the designer, 2026-10-27, W1-GP-27); spell defaults (to be fitted around the above):  A, E, R, F, 1-5 and Shift + the same (18 slots: 12 spells, 3 golden-slot abilities, 3 command-group keys)
- Taking a hit pushes the current cast back by 1.5 s; each hit pushes back again (no cap on pushbacks per cast); a cast can be pushed back down to 0 s remaining and no further; only stuns interrupt a cast; after a pushback the cast cannot be pushed back again for 0.5 s (hits taken meanwhile cost nothing), a new cast starts unlocked (designer, 2026-11-07)
- A stun cancels the cast in progress, with no other penalty than the stun's duration
- The global cooldown starts at the beginning of the cast
- Spell queue, WoW-style: the next spell can be pressed shortly before the end of the GCD or the cast and fires right away (designer: very important); the queued spell's action-bar button gets a pulsing gold outline (designer, 2026-10-27); the queue is cleared by a stun and by jumping, and by moving only while a cast is in progress (moving without a cast does not clear it, so instants queued while running survive) (designer, 2026-10-27, W1-GP-26)
- Reap is no longer off the GCD: it triggers a GCD of its own, 0.5 s (designer, 2026-10-27, W1-GP-21; supersedes the earlier "Reap off GCD, castable during a cast" answer of W1-GP-09). Reap cannot be cast during another cast or during a GCD: it waits like every other spell (can be queued) (designer, 2026-10-27, W1-GP-24)
- Moving or jumping cancels a cast (shown as a discreet grey Cancelled state, distinct from a stun interruption)
- Cast-time spells are cast on the ground only and standing still: not while jumping or falling, even with no movement key held; leaving the ground cancels a cast in progress (designer, 2026-11-03)
- Aim: fixed crosshair at the exact screen centre (0.5, 0.5) (designer, 2026-10-27, W1-GP-30); the aim trace goes from the camera through the crosshair and its impact point is the target; the spell leaves the character's hand toward that impact point (the offset between camera ray and hand is accepted); the character turns toward the aim when casting and keeps aiming during the cast (designer, 2026-10-27); a switch between raw aim and soft-target assist exists from week 1 for comparison (the final choice is still made in prototyping)
- Stun sources: the Mage's long charged spell, the Blademaster's parry
- Bull warriors (Tank, Berserker) cannot be stunned, as enemies and as soldiers (designer, 2026-10-29)
- Fillers build Souls, spenders consume them

## Resources
- Week 1 provisional numbers (designer, 2026-10-27): player HP 1000, training dummy HP 400 (it dies and respawns), player movement = WoW values (see the movement line, W1-GP-31), Deathbolt 60 base damage, infinite range, fast projectile speed (placeholder, designer will tune)
- Week 1 provisional values, confirmed as provisional (designer, 2026-10-27, W1-GP-20; to adjust after playing): spell queue window 0.4 s; soft-target assist angle 6 degrees, 150 cm around the ray, range 5000 cm; projectile 5000 cm/s, lifetime 10 s, radius 10 cm; dummy respawn 3 s; mouse wheel 50 cm per notch; debug hit 10 damage, debug stun 2 s; enemy overhead HP bar (designer, 2026-10-27, W1-UI-28): 120 x 12 px, 125 cm above the base, visible up to 5000 cm (50 m, designer 2026-10-29), hidden on death, full on revive, no value text
- Movement copies WoW (designer, 2026-10-27, W1-GP-31; 1 yd = 91.44 cm; WoW values, to confirm in game; the Gameplay Programmer may adjust a value after checking sources): run forward, strafe and backward all 640 cm/s (7 yd/s; no backpedal speed, W1-GP-32), gravity 1764 cm/s² (GravityScale 1.80, 19.29 yd/s²), jump take-off 727 cm/s (7.96 yd/s, about a 1.5 m jump), terminal fall speed 5500 cm/s (60.15 yd/s), no air control (trajectory locked at take-off; turning in the air does not change velocity), instant start and stop on the ground
- Facing while moving (designer, 2026-10-27, W1-GP-32): moving backward is as fast as forward (640 cm/s) and the character turns around to face its movement direction and runs toward the camera (no backpedal walk); forward and strafe (Q/D) still face the camera. When casting, the character turns toward the aim; an instant cast while running backward turns to the crosshair to fire, then resumes (main-session default, to confirm in play). Transition animations (180° pivot, turn in place) are being searched by the Animation Scraper.
- HUD layout (designer, 2026-10-27): player HP bar below the action bar; enemy HP bars above their heads (world widget); the week-1 HP bar and 12-slot action bar are provisional, the full HUD frame comes later
- Mouse and action bar (designer, 2026-11-08, for now): right click shows the cursor and the camera stops following the mouse; right click again hides it. With the cursor shown, spells are dragged between action bar slots (swap); the keys stay on the slots
- Pause menu (designer, 2026-11-08): Escape freezes the game and opens Continue, Settings (mouse sensitivity, volume, graphics quality, display), Quit
- Spirit: max 100 at level 1, +20 per player level (380 at level 15)
- Spirit: spent only on Raise and revives; revive cost = 60% of that soldier's raise cost, rounded down (revivePercent on the economy/spirit doc)
- Raise cost: Shadow 50, Asset 75, Ace 110, General 150; +10 per S grade, -10 per B grade (so 20 to 180); numbers on the Rank Odds board, economy/spirit doc; no other spell costs Spirit
- Spirit gains: 50 on entering each section (up to the cap), 5 per Reap, some variant passives; this exchange rate is intended; target: about 2-3 raises per section at tier 1; at tier 20 about 2-3 Generals per section
- HP: no regeneration over time; healed by Hunger and by Reap for HP (2 s cast, 20% of max HP)
- Spirit never regenerates over time; regained a little at each new section, by Reap, and by some variant passives
- Souls: short-loop resource, Soul Shard-style; kills and Reap give no Souls
- Souls: max 6; each spender costs 3; Deathbolt gives 1; Splinters gives 1 (2 with a proc); Rot gives 0; Souls are given only when the spell hits a target, once per cast, a miss or a wall gives none (designer, 2026-11-08)
- No currency: no gold, no shop

## Abilities
- Names are final; Death Nova was renamed Raw Nova and Deathbolt keeps its name (designer, 2026-10-29)
- Aimed: Deathbolt, Unholy Impale, Rot (hitscan), Swap, Raise, Reap (soft targeting decided in prototyping)
- Cone toward the aim: Splinters. Ground circle: Raw Nova, Grasp. Aimed: Hunger
- 7 spells at the start (Deathbolt, Unholy Impale, Splinters, Raw Nova, Raise, Reap, Hunger); 5 unlocked by player level (Grasp, Swap, Frenzy, Rot, Power of Below)
- Variants are equipped in variant slots unlocked by player level (6 by level 15); one variant per spell at most
- Deathbolt: single-target cast-time filler, last in priority
- Unholy Impale: single-target spender
- Unholy Impale look (designer, 2026-11-08): a spear that forms to the right of the crosshair, above the casting arm, during the cast (not in the hand; designer, 2026-11-08: FormOffset 35, 85, 75 from the caster), flies with the Deathbolt's trail, goes half its length into what it hits (wall or enemy), stays 10 s, then shrinks and is destroyed
- Splinters look (designer, 2026-11-08): shards of cut stone, tombstone fragments, always wrapped in the arm's spell effect
- Rot look (designer, 2026-11-08, W2-GP-14): cyan-turquoise veins crawl over the cursed enemy from where the curse landed and pulse brighter with each damage tick; a thin thread links the arm to the target at the cast
- Spell colour (designer, 2026-11-08): when he says "verdâtre" he means the arm's cyan-turquoise
- Raise look (designer, 2026-11-08): the mob rises slowly in smoke swirling toward the sky, levitates for 2 s while its material gradually changes and the summon aura appears, then drops to the ground and is functional
- Hunger look (designer, 2026-11-08): a cyan-turquoise bite effect on the chosen soldier, arcs of fangs snapping shut
- Reap look (designer, 2026-11-08): the bite appears to eat the corpse for 2 s; the corpse bleeds at each bite and gently explodes at the end in a mix of blood and cyan-turquoise magic
- Frenzy look (designer, 2026-11-08): a shout animation on the player; the soldiers' aura doubles in volume and a transparent red circle at their feet shows the buff
- Power of Below look (designer, 2026-11-08): a shout animation; the arm's aura spreads over the whole body and a transparent cyan-turquoise circle sits under the character for the duration of the buff
- Splinters: instant AoE cone toward the aim, 30° wide, starting from a flat base about twice the player's width (hits enemies right next to him), rounded far edge; weak, builds Souls; 2 charges, 5 s recharge per charge (3 s during Power of Below); cone length 40 m (provisional, to check in play, designer 2026-10-29)
- Splinters proc: any player hit except Splinters' own has 10% chance to grant a free Splinters charge and double its next hit; Rot's first hit 10%, later Rot ticks 1%; soldiers' hits never proc
- Splinters: up to 2 procs held, so at most both charges are empowered; never more than 2 charges, never more than double damage per charge
- Free spender proc: each enemy hit by Splinters has 5% chance to make the next spender cost no Souls; only one stored; AoE dominating the rotation is intended
- Splinters proc empowers the charge it grants; with 2 charges already, it empowers an existing charge; with 2 procs active, a third proc is lost
- Raw Nova: AoE spender; a circle on the ground shows the zone during the cast and follows the aim (designer, 2026-11-08)
- Grasp: root (designer, 2026-11-08: ground circle like Raw Nova; every target hit takes low damage and is rooted for 4 s; ghostly hands come out of the ground and grab the legs, 3 pairs of arms around each target, scaled to the size of the mob so it reads on every mob)
- Swap: swap places with a soldier (designer, 2026-11-08: the camera travels to the swap target first; meanwhile smoke appears on the player and the targeted summon, hiding the swap for a clean transition)
- Frenzy: timed buff on soldiers
- Hunger (replaces Death Trap): instant, aimed; targets only the player's own soldiers; hitting one of your summons consumes it, healing the player by its remaining HP; castable while moving; 10 s cooldown; the eaten soldier becomes a corpse again, revivable for 60% of its raise cost (intended loop); Chosen cannot be eaten; heal capped by the eaten soldier's rank: max 30% of player max HP (Shadow), 40% (Asset), 50% (Ace), 60% (General)
- Rot (replaces Flying Filthy Dagger): instant, generates no Souls; hitscan curse on the aimed target, damage every 1 s for 10 s; can be on several enemies at once; recast on a cursed target refreshes the duration to 10 s (no stacking)
- Power of Below: personal offensive cooldown; GCD 0.75 s, cast times halved, spenders instant, Splinters recharge 3 s; lasts 15 s, cooldown 120 s (provisional, designer 2026-10-29); unlocked by player level (Level Unlocks board)
- Base rotation (no talismans): spender (Unholy Impale ST / Raw Nova AoE) if Souls capped (never overcap) > Splinters with proc > spender > Rot on main target if not cursed > Splinters > Deathbolt
- Reap: consume a corpse for a 10 s buff (no Souls) (variants: HP regen, damage, speed), plus a mouse choice after pressing Reap: left click = 5 Spirit (instant), right click = 20% of max HP (2 s cast, stand still, pushback applies); a corpse left by Hunger can be reaped too
- Reap base buff (no Reap variant equipped): every army soldier heals 1% of its HP per second for 10 s
- Each ability has 2 unlockable variants (Reap has 3); variants not yet defined

## Army
- Weapon: a spectral dark-magic arm (no blade): non-physical, translucent, glowing, with wisps and clawed fingers, yet able to strike, grab and hold things; it must stand out in every animation
- Raise: performed with the dark-magic arm, cost by rank and grades, cast time, must be close; any rank the player meets can be raised
- 10 army slots max at endgame
- No orders: soldiers attack the first enemy they see
- 3 command groups, set by drag and drop in the army tab; each group's hotkey selects it and swaps the action bar to the order bar (Attack, Protect, Move), like a WoW Rogue's stealth bar; giving an order swaps back to the spells instantly; pressing the group key again swaps back without an order
- All 10 army slots are open from the start
- Dismissing a soldier frees its slot
- 3 golden army slots: a soldier there gives its type ability to the player as a spell
- Orders: Attack, Protect (attack the biggest threat to the player), Move
- Collection: winning a run adds the soldiers raised and won with; Chosen (soldiers brought from it, 0-3 by player level) stay in it whatever happens
- Each run: bring up to 3 Chosen from the collection (none at level 1), raise the rest on the battlefield
- Raised soldiers: join the collection on a win; lost on a defeat
- Any fallen soldier can be revived for 60% of its raise cost, during combat too: casting Raise on a dead summon revives it (designer, 2026-10-29); a raised soldier not revived before leaving the current section is lost for the run
- All kept soldiers revive automatically when a run ends

## Soldier roster (enemies and soldiers share it)
- Guard: sword and shield footman; sometimes shields up (stands, turns slowly). Combat block v1 (provisional, designer 2026-11-07): 500 HP, sword 40 damage every 2.5 s (was 2 s), reach 2 m, notices the player at 20 m, the player's walking speed; the corpse stays after death. Player ability: Guard, damage reduction for 1.5 s
- Mage: ranged arcane bolts; occasional long charged spell for massive damage that stuns; focuses its biggest threat. Player ability: TBD
- Rogue: dual blades, fast, high damage, squishier than Guards; focuses player and elites; 1 s windup then dash through normal mobs. Player ability: TBD
- Tank (bull warrior, cannot be stunned): armoured, slow, hits hard, very tough. Player ability: Taunt (all nearby enemies focus the Tank, Rogues included)
- Blademaster: two-handed, sturdy, hits hard, fairly fast; occasional parry with a visible windup, sends damage back and stuns. Player ability: Parry (sends an attack back at 2x damage)
- Berserker (bull warrior, cannot be stunned): leaps onto its target; Whirlwind, a quick simple AoE around itself (not a long channel). Targeting: fights melee soldiers first, the strongest first (designer, 2026-10-29); leap range and Whirlwind details TBD. Player ability: TBD
- Elites: any mob can be one; aura, slightly different palette, stat boost
- A raised elite is captured (Pokémon-style) and sent to the collection at the base, not to the run's army; every fallen elite can be captured, with no limit per run
- A captured elite keeps its elite status and stats, but is lost if the player loses the run (no death farming)
- Capture works like a normal raise for now; a special capture (rhythm mini-game?) is planned for later
- The base = the menu between runs, holding the collection: choose Chosen to bring (up to 3), talismans, difficulty
- Player level: max 15; levels 2-15 unlock 5 spells, 6 variant slots, 3 Chosen slots (first at level 2) (order on the Level Unlocks board); levels are gained at the end of a run; experience is kept even on a lost run
- At the base, a Rename button lets the player rename any soldier (optional)

## Names and grades
- Every mob gets a random name from a list of 200 European first names (data/mob-names.csv)
- Alive, all mobs of a type share the same stats
- Hidden grades rolled at random, one per stat: Vitality (max HP), Attack (damage), Speed (cast speed for ranged, movement speed for melee)
- Grades: S = 1.25x, A = 1x, B = 0.75x
- Rank (Solo Leveling-inspired): Shadow = 1, Asset = 2, Ace = 3, General = 4; boosts all stats, never changes grades
- A better rank almost always means a better soldier (intended); grades decide within a rank
- Difficulty tiers are endless; tier 20 = top end game; beating a tier unlocks the next
- Up to tier 20, enemies get stronger through their number and ranks
- Above tier 20: odds and enemy numbers stay as at tier 20; each tier adds +20% damage and HP to every enemy (21: +20%, 22: +40%...); enemies only, not kept when raised or captured
- Enemies per fight: a random number in a range per tier (2-3 at tier 1, 12-15 at tier 20), on the Rank Odds board
- Ranks by tier: Asset from tier 3, Ace from tier 8, General from tier 14; exact rank and grade odds live on the Rank Odds board (source of truth)
- A Chosen above the tier's highest rank fights at that rank
- "Level" means only the player's level (1-15); ranks use a rank number (1-4)
- Effective stat = (Base x Grade) x (1 + (Rank number − 1) x 0.5): Shadow 1x, Asset 1.5x, Ace 2x, General 2.5x
- Rank on enemies: shown on the health bar (default modern WoW retail nameplate style), no effect on the body
- Enemy health bars (designer, 2026-10-29): shown within 50 m of the player; elites have a gold frame; no name over a living mob; the name appears in the widget frame after its death, and when the unit is selected with a left click; a rank symbol sits left of the bar: circle = Shadow, rhombus = Asset, rounded square = Ace, faceted diamond (gem) = General (shapes provisional)
- Elites: gold outline on the health bar
- Rank on corpses: faint aura, weaker than on summons but visible
- Rank on summons: an aura that dominates the summon palette
- Aiming at a corpse opens a world widget above it: name, rank, grade of each stat; gold outline for elites
- Holding Alt shows all health bars and all corpse widgets at once
- Higher difficulty tiers: better odds of high grades

## Gear
- Talismans only, no armour: found in hidden chests or dropped by foes
- Talisman target: 2–3 new talismans unlocked per completed run (drop rate set once fight sizes are known)
- Equip 2 before a run; each boosts the stats of one specific spell

## Run
- Current scope: one level with a boss at the end
- The level is outdoors, 5 sections per run, each of about 5 fights, cleared one after another; no going back to a previous section
- Win: kill the boss. Lose: player HP reaches 0
- Difficulty tiers like Mythic+: stronger mobs, better grade odds, more experience

## Art
- Concepts: GPT images → 3D with Meshy AI
- Animations are authored on the UE5 Mannequin skeleton (SK_Mannequin); a character on another skeleton (the Hero) plays them through an IK Retargeter at runtime
- Python Editor Script Plugin enabled (designer 2026-10-28, W1-TD-42) for editor tooling only: import, naming, cutting and retargeting of animations (Mixamo/GASP → Manny); no gameplay logic in Python, gameplay stays C++
- Hit reactions (designer 2026-10-28, W1-ANIM-44): only the Mixamo "Small" reacts are used, never the "Large" ones; damage feedback must never make the character or mobs step back (in-place, upper body)
- GASP clips: the agent selects the ~40 needed M_Neutral_* clips by script (exact names from the inventory) and migrates them itself, headless (W1-ANIM-43)
- Mixamo clips are converted to the UE5 Mannequin skeleton with Mixamo Converter before import (designer's pipeline, 2026-10-28, W1-ANIM-45): imported directly onto SKM_Manny_Simple / SK_Mannequin, no skinned FBX and no IK retarget; source folder C:\Users\march\Desktop\Mixamo's DarkTouch Assets
- Animation sources, week 1 (2026-10-28): GASP (Epic, Unreal-only licence) for locomotion, pivots, turns, jumps; Rokoko free magic pack + Mixamo for one-hand casts; Mixamo in-place "React" clips for hit reactions, played on the upper body through a per-bone layered blend so the character keeps running; free sources first, no paid packs for now; raw source art (FBX) in UE5 Project/SourceArt/ is never committed (ignored in git, designer 2026-10-28, W1-ANIM-41), only imported .uasset files are
- Player = 1 skeletal mesh (body and cursed arm together, 1 material) shown by the player; designer 2026-11-02: the 2-mesh split caused more problems than it solved
- Hero rigged by AccuRIG (designer 2026-11-02, W1-ANIM-59 option C): Meshy v4 model (Art/Characters/Hero_Meshy_v4: short mantle on the shoulders, no strips down to the hips; cloth simulation later only on the mantle fringes, designer 2026-11-02), AccuRIG rig with Unreal bone names on its OWN skeleton (SK_Hero_AR, SKM_Hero_AR, MI_Hero_v4); the player runs the animation on a hidden SKM_Manny_Simple and the visible Hero copies the pose at runtime through RTG_Manny_to_Hero (C++ URetargetFromParentAnimInstance); all Manny/Mixamo/GASP clips stay on SK_Mannequin. No cloth simulation for now. Before any rig hand-over: the test bench (9 clips, close-ups of hands, elbows, neck, shoulders, cloak) is rendered and checked. The previous Hero (SKM_Hero, hero_v2) stays in the project, unused
- The Hero AccuRIG v4 setup is validated (designer 2026-11-02, W1-ANIM-60). Next: Chaos Cloth on the mantle fringes only (SKM_Hero_AR), done by the main animation session.
- Player locomotion for now: the UE5 template clips (MM_Idle, MF_Unarmed_Jog_*, MM_Jump / Fall_Loop / Land), turn in place off; the GASP clips stay in the project, unused (designer 2026-11-02)
- Main character look: horned hood, ornate golden mask with glowing cyan eyes, tattered olive-green mantle, dark leather armour with gold trims and chains, no long coat (trousers, straps, wrapped boots), athletic build close to Manny; reference images/main-character.png
- The dark-magic arm is cyan-turquoise
- Rank colours: Shadow pale green, Asset purple, Ace black with thin silver edge, General deep red with black outline
- Summon aura: overlay on the skeletal mesh material + small smoke, dominates the base material
- Enemy palette (warm): burnt orange #C8641E, ivory #E8DCC0, warm steel #9A9590, tan leather #8A5A34, warm skin #C99A7A
- Summon palette (cold): slate #5E6670, ashen blue-grey #3E4650, corpse pale #A9B0B0, emissive cyan #3FE0D0
- One material per type; a Raised parameter switches enemy palette to summon palette
- Elites: enemy palette, richer: darker saturated orange, dark-bronze armour, bigger trims

## Audio
- Dark neoclassical; the cello always leads the melody
- No phonk for now; tested only if the music lacks impact (designer, 2026-10-29)
- Adaptive layers: exploration, combat, boss
- Raising a soldier has an iconic cello motif
- Sound effects: generated by the designer on ElevenLabs from the Sound Designer's prompts, on a plan that allows commercial use; tracked in review/sons.csv (designer, 2026-11-07; was: free sound banks CC0, Pixabay, CC-BY)
- Sound tone: dark, grounded, weighty; nothing too fantasy or cheap-sounding (designer, 2026-11-07, W1-SND-02)

## Production rules
- Course end date: 24 November 2026 (designer, 2026-11-07); the demo must be playable by then (the plan assumed 13 December)
- Whole first, then polish: a feature is added complete in a first version on every layer (code, UI, feel and VFX, animation, audio, level); polish comes after
- Everything must be reusable in a future project: generic systems as C++ Actor Components driven by data tables or data assets, UInterfaces, delegates and Gameplay Tags; an automation test for every rule with a number
- Generic systems in the C++ plugin Plugins/GameSystems/ (one module per system); Dark Touch code in Source/DarkTouch/, content in /Game/DarkTouch/; the plugin never references the game module
- Generic names; a README.md per system; systems.md marks each system reusable or game-specific
- Assets (animations, sounds, music) only under licences that allow reuse; source and licence recorded
- Verify before handing over: build the C++ and fix every error and warning, relaunch the editor, run the automation tests, compile and save any Blueprint touched, PIE smoke test when gameplay changed, read the log and crash reports; fix it yourself; never hide an error; after 3 failed tries report it to the designer (rules in the UE5 project's CLAUDE.md, enforced by a hook)

## Tuning boards (source of truth for data tables)
- Level Unlocks board: https://claude.ai/artifact/NqX8sL4fDcjPXyauHew4vz (ArtifactData collection "progression", doc "order": unlocks for levels 2-15 in order)
- Rank Odds board: https://claude.ai/artifact/DfuKmSVMsquH5RjLVcJHt3 (ArtifactData collection "tiers", one doc per tier, plus collection "economy", doc "spirit": raise costs by rank, grade adjustments, revive % of raise cost (revivePercent), section entry, reap, max Spirit base and per level; tiers docs: enemiesMin, enemiesMax, then shadow, asset, ace, general, gradeS, gradeA, gradeB as whole %)
- Tiers above the last row use the last row's odds

## Validated assets
(Add one line per validated asset: name, file, date.)
- Main character concept, front and back: images/main-character.png, 2026-10-22

</document>

<document name="Agentic Documentation/lore.md">
# Dark Touch — Lore

Part of the [Dark Touch GDD](GDD.md). Simple for now; to be expanded later. Magic, peoples and the player's origin validated by the designer on 2026-10-29.

## The world

**Cel'ardor** (working name). The whole continent is at war.

## The story

You are a half-breed, part dragonkin and part human, who lost an arm and had never wielded magic. You accepted a pact with a dark entity you know little about. It gave you a magic arm that casts spells on its own, granting you the powers of a necromancer. The arm is your first magic.

You wake up in a small town. To protect the village, you raid the enemy army before it can attack. You know you must learn magic from scratch with this new power, so you are glad to start by protecting a small village, and later bring destruction to your enemies once you have mastered it.

## Magic

- **Only the dragonkin can wield magic:** elemental, arcane and dark magic alike.
- **A human body cannot withstand magic.** Without special gear that cancels its side effects, a human cannot use it.
- **The player wields magic only through the arm** the dark entity gave him in the pact.

## Peoples

- **Dragonkin** — the born wielders of magic. The Mages are dragonkin.
- **Humans** — no magic of their own. The Guards, Rogues and Blademasters are human. A few gain access to a little of it through special gear. The **Blademaster** is one of them: he owns gear that lets him use a little magic, and he has trained to push that little to its full potential. His parry, which reflects damage back, is that magic.
- **Bull warriors** — the race of the Tanks and the Berserkers. They have a strong resistance to magic, which makes them a natural counter to mages, and their strength makes them very dangerous against humans. They can use magic, but only to infuse their gear or their own body; they cannot cast spells. Bull warriors cannot be stunned.
- **The player** — a half-breed, part dragonkin and part human. He had never wielded magic before the pact.

## Still to write

The entity, the war and its factions. See [Open questions](open-questions.md).

</document>

<document name="Agentic Documentation/art-direction.md">
# Dark Touch — Art Direction

Part of the [Dark Touch GDD](GDD.md). Decisions only; open points are in [Open questions](open-questions.md).

## Style

Stylised, in the spirit of **Fellowship**. The world is Cel'ardor, a continent at war (see [Lore](lore.md)).

## Pipeline

1. Concept images created with GPT image generation.
2. 3D characters generated from those images with **Meshy AI**.
3. Characters rigged to the UE5 Mannequin skeleton (see below).

## Skeleton and character setup

- **Every character uses the UE5 Mannequin skeleton**, so animations are shared without retargeting.
- **The player is one skeletal mesh** on that same skeleton (designer, 2026-11-02; it used to be body + arm as two meshes). The cursed arm has its own material slot "Arm", so it still gets its own material and effects without touching the body.
- **Cloak:** only the long hanging strips are simulated cloth; the hood and the shoulder cloth follow the skin, never the simulation (designer, 2026-11-02).

### The main character

Validated concept (front and back), the reference for the 3D model:

<img src="images/main-character.png" alt="Main character concept, front and back" width="560">

- **Hood** with two small golden horns; **ornate golden mask** with glowing cyan eyes, the face lost in shadow.
- **Tattered olive-green mantle** over the shoulders, longer at the back, down to the waist.
- **Dark brown leather armour** with thin gold trims; **golden chains** across the chest and kept short and tight at the belt.
- **No long coat:** the outfit stops at the belt. Below it, only fitted leather trousers with buckled straps and wrapped leather boots, so the legs need no cloth animation.
- **Athletic build**, close to the UE5 Manny proportions, so the rig and shared animations fit with little clipping.
- **Left arm:** normal, in a dark leather glove. **Right arm:** the dark-magic arm, in **cyan-turquoise**, matching the eyes.
- Only the mantle may need light physics (one Kawaii Physics or AnimDynamics chain on its back strips).

### Enemy references

Validated mood references for four enemy types (also the soldier versions, since enemies and soldiers share the roster). They set the look; the 3D models are generated from a clean turnaround made from them. The images are third-party art kept locally for reference only (not committed).

| Type | Reference | Key traits |
| --- | --- | --- |
| Berserker | `images/references/berserker.jpg` | Bull warrior, massive black bull-headed brute (minotaur): huge horns, double-bladed axe, glowing red runes, bull skull at the belt, torn red loincloth, spiked bracers and greaves |
| Mage | `images/references/mage.jpg` | Draconic mage: blue-and-white scaled dragon head and hands, navy and cream robe with geometric trims, staff topped with a blue crystal, blue spell glow in the free hand |
| Blademaster | `images/references/blademaster.jpg` | Dark ornate plate armour, closed helm, white fur collar, tattered cloak, long two-handed greatsword stained with blood |
| Tank | `images/references/tank.jpg` | A bull warrior (like the Berserker) in the reference's armour: bull head and horns under or through the helm; heavy spiked grey plate armour, torn red cape and tabard, large shield with a red dragon emblem, sword with glowing red veins (the war banner is a prop, optional) |

For the Mannequin skeleton: keep human proportions under the look. **Bull warriors (Berserker, Tank) keep their hooves** (designer, 2026-10-29): the legs keep a human shape and human joints down to the ankle, and each ends in a large cloven hoof sitting flat under the ankle, its bottom acting as heel and sole. At skinning, the whole hoof is weighted 100% to the `foot` bone; the toe bones (`ball_l`, `ball_r`) stay in the skeleton for the shared animations but carry no weight, so the hoof stays rigid. The Mage's clawed digitigrade feet become plantigrade feet in the turnaround; horns, tails of cloth and capes are fine but kept short below the hips; weapons, shields and staffs are separate meshes attached to the hand sockets.

## The weapon: the dark-magic arm

The player fights without a blade. The right arm is not physical: it is pure dark magic, translucent and glowing **cyan-turquoise**, made of swirling spectral energy that drifts off as wisps and particles, with long clawed fingers. Although it is not flesh, it acts like a real arm: it can **strike, grab and hold things**, which is how it casts, raises and reaps.

<img src="images/arm-reference.png" alt="Reference: the spectral dark-magic arm" width="320">

*Early reference for the arm's shape and effects; its colour is now cyan-turquoise, as in the main character concept.*

It is the game's visual signature and **must stand out in every animation**: casting, raising, reaping and idle all need a distinctive effect on the arm.

## Environment assets

Level assets (rocks, trees, ruins, war camp and village props, chests, ground, sky) are stylised and slightly desaturated so characters and the cyan arm pop. They are found by the [Environment Scraper](agents/environment-scraper.md) and reviewed on the [Environment Board](https://claude.ai/artifact/5TxnhfWgdumWg5oXVUhABd).

## Readability palettes

**Enemies are warm and alive; summons are cold and spectral.** Warm against cool reads fastest, and orange against cyan stays clear for colour-blind players. Each type uses one mesh with one material: a "Raised" parameter switches it from the enemy palette to the summon palette and lights up the cyan glow.

| Enemies (living) | Hex | Summons (raised) | Hex |
| --- | --- | --- | --- |
| Tabards and cloth: burnt orange | `#C8641E` | Body and armour: slate grey | `#5E6670` |
| Secondary cloth: ivory | `#E8DCC0` | Cloth: ashen blue-grey | `#3E4650` |
| Armour: warm steel | `#9A9590` | Skin: corpse pale | `#A9B0B0` |
| Leather: tan | `#8A5A34` | Eyes, veins, cracks (emissive): the arm's cyan | `#3FE0D0` |
| Skin: warm flesh | `#C99A7A` | | |

- Summons share the player's cyan, so they read as his. The main character (dark brown, olive, gold) reads as neither.
- Elites keep the enemy palette, richer: darker, more saturated orange, heavier dark-bronze armour, bigger trims.
- Check: an enemy and a summon side by side must stay distinct in black and white.

## Rank colours

Each rank has a colour:

| Rank | Colour |
| --- | --- |
| Shadow | Pale green |
| Asset | Purple |
| Ace | Black, with a thin silver edge so it reads on dark shapes |
| General | Deep red with a black outline, kept distinct from the enemies' orange |

- **On enemies:** no effect on the body. The rank shows on the **health bar**, styled like the default modern WoW (retail) nameplate health bar, with no add-ons. **Elites** get a **gold outline** on their health bar.
- **On corpses:** a **faint aura**, weaker than on summons but still visible, so the player can scan the battlefield for good ranks. Aiming at a corpse opens a world widget above it with its name, rank and stat grades (gold outline for elites); holding **Alt** shows every health bar and corpse widget at once.
- **On summons:** the rank is an **aura**, an overlay on the skeletal mesh material plus a little smoke. It **dominates the summon palette** and is more visible than the base material.

## Elites

Any mob can be an elite: it has an aura, a slightly different colour palette, and a stat boost over the normal version. A raised elite is captured and sent to the army at the base.

</document>

# Task
Write one GPT-image concept-art prompt for each of these spells: Raise, Reap, Hunger, Grasp, Swap, Frenzy, Rot, Power of Below, Splinters. The designer described what he imagines below: keep his idea, develop it, never replace it.
<designer_ideas>
# Spell ideas, in the designer's words (2026-11-08)

Note from the designer: « ce que j'appelle verdâtre est cette couleur cyan-turquoise ». Wherever these notes say "verdâtre", the colour is the arm's cyan-turquoise (#3FE0D0), never a true green.

## Grasp
Sur une zone en rond telle que la Raw Nova, toutes les cibles touchées prennent des dégâts faibles et sont immobilisées sur place pendant 4 secondes.
Des mains fantomatiques sortent du sol et attrapent les jambes des ennemis touchés. Pas besoin que ce soit pixel perfect, je veux juste voir 3 paires de bras qui entourent la cible au niveau des jambes. Cela doit scaler également avec la taille du mob pour que ça fasse sens et que ce soit bien visible pour chaque mob.

## Swap
Je veux que la caméra travel en premier vers la cible du swap. Pendant ce temps une fumée apparaît sur le player et le summon ciblé. Cette fumée cache le swap de position et offre une transition clean.

## Splinters
On doit aller vers des éclats de pierres taillés, des éclats de tombe dans l'idée, toujours entourés de cet effet verdâtre du bras propre aux spells.

## Raise
Le mob doit se relever lentement dans une fumée tourbillonnante vers le ciel. Ensuite pendant 2 secondes il doit léviter et changer graduellement son matériau, ainsi qu'avoir l'aura caractéristique des summons qui apparaît, puis il retombe au sol et est maintenant fonctionnel.

## Hunger
Un Niagara dans le style de l'image de référence du designer : une morsure sur le mob choisi, la couleur verdâtre et non orange.
Reference image, described: two glowing curved arcs of pointed fangs, one above and one below, snap shut on the target, then a bright four-point star flash with thin radiating sparks. Style reference only, third-party: do not name or copy it.

## Reap
La morsure fait mine de manger le cadavre pendant 2 secondes. Pendant ces deux secondes le cadavre saigne à chaque morsure, et explose doucement à la fin en mélange de sang et de magie verdâtre.

## Frenzy
Une animation de cri sur le player. Sur les soldats, leur aura double de volume et un cercle rouge transparent à leurs pieds montre qu'ils sont sous l'effet du buff.

## Rot
Designer's choice among three proposed ideas (W2-GP-14, option A): cyan-turquoise veins of rot crawl over the cursed enemy's body, spreading from where the curse landed, and pulse brighter once per second with each damage tick. A thin thread of cyan-turquoise links the arm to the target at the moment of the cast. It stays readable when several enemies are cursed at once.

## Power of Below
Une animation sur le perso, un cri aussi. On fait passer l'aura du bras sur tout le corps et on met un cercle verdâtre transparent sous le personnage pendant la durée du buff.

</designer_ideas>

Return {"spells": [{"spell": "Raise", "designer_idea": "his words, short", "prompt": "English prompt, 40-130 words", "aspect": "16:9"}]}.

# Revise
Your previous version:
{
 "spells": [
  {
   "spell": "Raise",
   "designer_idea": "The mob rises slowly in swirling smoke toward the sky, levitates 2 s while its material gradually changes and the summon aura appears, then drops and is functional.",
   "prompt": "Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers is stretched toward a fallen soldier. The soldier rises slowly and levitates a metre above the ground in smoke spiralling up toward the sky. Its body is mid-transformation: burnt orange and ivory cloth fading into cold slate and ashen blue-grey with pale skin, emissive cyan veins spreading across it. A rank aura gathers around it. A desaturated battlefield background, with bold silhouettes readable from far away. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Reap",
   "designer_idea": "The bite pretends to eat the corpse for 2 s; the corpse bleeds at each bite and gently explodes at the end in a mix of blood and cyan magic.",
   "prompt": "Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers is held over the corpse of a fallen enemy wearing burnt orange and ivory cloth with warm steel armour. Spectral cyan-turquoise jaws bite into the body, and dark blood spurts at each bite. The corpse is swelling and bursting softly in a gentle burst of red blood mixed with glowing cyan-turquoise magic, with drifting wisps. Clear silhouettes, slightly desaturated ground, readable from far away. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Hunger",
   "designer_idea": "A bite Niagara on the chosen mob: two curved arcs of fangs snap shut, then a bright star flash with thin sparks, in the arm's cyan-turquoise, not orange.",
   "prompt": "Stylised dark-fantasy effect study of a bite spell on one of the hero's own raised soldiers, a cold slate-grey and ashen blue-grey spectral warrior with cyan veins. Two glowing curved arcs of pointed fangs, one above and one below, snap shut on it, drawn in the cyan-turquoise of the hero's spectral right arm. Right after the bite, a bright four-point star flash bursts out with thin radiating sparks. Strong readable shapes against a slightly desaturated dark background, viewed from behind and above the hero. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Grasp",
   "designer_idea": "A round ground zone like Raw Nova; ghostly hands come out of the ground and grab enemy legs, 3 pairs of arms around each target, scaled to the mob's size.",
   "prompt": "Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with clawed fingers is pressed toward the ground. A large glowing circle on the ground marks the zone. Inside it, three enemies of different sizes in burnt orange and ivory gear are held at the legs by ghostly cyan-turquoise hands rising from the soil, exactly three pairs of arms around each one, longer and thicker on the biggest mob. Slightly desaturated terrain, bold readable silhouettes. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Swap",
   "designer_idea": "The camera travels to the swap target first; smoke appears on the player and the targeted summon, hiding the swap for a clean transition.",
   "prompt": "Stylised dark-fantasy concept art of the swap moment, seen from behind and above the hero. The hero, with his translucent cyan-turquoise spectral right arm with long clawed fingers extended, is wrapped in a thick billowing cloud of dark smoke, laced with cyan-turquoise wisps. Several metres ahead, one raised soldier in cold slate grey and ashen blue-grey with cyan veins is hidden in the same kind of smoke. A faint cyan trail links the two clouds. Clean desaturated battlefield, simple readable shapes. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Frenzy",
   "designer_idea": "A shout animation on the player; the soldiers' aura doubles in volume and a transparent red circle at their feet shows the buff.",
   "prompt": "Stylised dark-fantasy concept art, seen from behind and above the hero, who throws his head back in a roaring shout, his translucent cyan-turquoise spectral right arm with long clawed fingers flung wide. In front of him stand three raised soldiers in cold slate grey and ashen blue-grey with cyan veins, each wrapped in a rank aura now twice as big and billowing. Under each soldier's feet lies a transparent red circle glowing on the ground. Slightly desaturated ground, bold silhouettes readable from far away. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Rot",
   "designer_idea": "Cyan-turquoise veins of rot crawl over the cursed enemy from where the curse landed and pulse with each damage tick; a thin thread links the arm to the target at the cast.",
   "prompt": "Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers points forward. A thin cyan-turquoise thread links his hand to the main target, an enemy wearing burnt orange and ivory cloth with warm steel armour. Glowing cyan-turquoise veins crawl across its body from the point where the curse struck, pulsing bright. Two other enemies nearby show smaller patches of the same veins, so several curses read clearly. Slightly desaturated background, bold readable silhouettes. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Power of Below",
   "designer_idea": "A shout animation; the arm's aura spreads over the whole body, with a transparent verdâtre (cyan-turquoise) circle under the character for the buff's duration.",
   "prompt": "Stylised dark-fantasy concept art, seen from behind and above the hero, who roars with his head raised and arms open. The aura of his translucent cyan-turquoise spectral right arm with long clawed fingers spreads across his whole body, wrapping horned hood, mantle and armour in flowing cyan-turquoise energy and wisps. Under his feet a large transparent cyan-turquoise circle glows on the ground. A slightly desaturated dark battlefield behind him, strong silhouette readable from far away. No text, no logo, no watermark.",
   "aspect": "16:9"
  },
  {
   "spell": "Splinters",
   "designer_idea": "Cut stone shards, tombstone fragments, always wrapped in the arm's verdâtre (cyan-turquoise) spell effect.",
   "prompt": "Stylised dark-fantasy concept art, seen from behind and above the hero, whose translucent cyan-turquoise spectral right arm with long clawed fingers is thrust forward. A cone of sharp cut-stone shards and broken tombstone fragments with carved edges spreads about 30 degrees from a flat base roughly twice the hero's width right in front of him, ending in a rounded far edge. Each shard is wrapped in glowing cyan-turquoise spell energy and wisps. The shards tear into a group of enemies wearing burnt orange and ivory cloth with warm steel armour, one standing right beside the hero inside the cone. Slightly desaturated graveyard ground, bold readable shapes. No text, no logo, no watermark.",
   "aspect": "16:9"
  }
 ]
}

Fix every problem below and change nothing else:
- Critic on Hunger.prompt: The raised soldier is described only by its slate palette and cyan veins, with no rank aura, so the image would show a summon without its most visible marker. (canon.md, Names and grades: 'Rank on summons: an aura that dominates the summon palette'; art-direction.md, Rank colours, says the same. The Raise and Frenzy prompts include the aura.)
