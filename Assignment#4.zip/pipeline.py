#!/usr/bin/env python3
"""Dark Touch content pipeline (Assignment 4).

Each target goes through the same loop, at most --max-rounds times:
  1. READ      the game documents (canon, lore, audio, art direction, open questions, GDD).
  2. GENERATE  with the project's own agent definition as the system prompt.
  3. CHECK     with deterministic rules taken from those documents (no LLM).
  4. CRITIC    a separate Game Director agent reviews the output against the documents.
  5. REVISE    the generator gets back every failed rule and every blocking critic issue.

Standard library only (Python 3.9+). Runs in three modes:
  python pipeline.py                     live run, needs a logged-in `claude` CLI
  python pipeline.py --replay            same loop on the recorded model replies, no login needed
  python pipeline.py --self-test         proves the checks and the loop work, no model at all

Nothing here writes to the game: outputs land in Assignment-4/outputs/ as proposals.
"""
import argparse
import concurrent.futures
import csv
import filecmp
import json
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
SNAPSHOT = HERE / "sources"
OUTPUTS = HERE / "outputs"
RECORDINGS = HERE / "recordings"
RUNS = HERE / "runs"
INPUTS = HERE / "inputs"

DOCS = "Agentic Documentation"
AGENTS = ".claude/agents"
SOUND_TRACKER = "review/sons.csv"

CRITIC_AGENT = f"{AGENTS}/game-director.md"
CRITIC_MODEL = "opus"
BLOCKING = {"blocking", "should_fix"}
MIN_TONE = 4  # Below this critic score, "does it sound like Dark Touch" sends the output back like a rule failure.

# Facts the deterministic rules enforce. Each one is quoted from the document named next to it.
CAST_TIMES = {"Deathbolt": 1.5, "Unholy Impale": 2.0, "Raw Nova": 2.0}  # canon.md, "Cast times"
ROSTER = {"Guard", "Mage", "Rogue", "Tank", "Blademaster", "Berserker"}  # GDD-full.md section 8
STARTING_SPELLS = {"Deathbolt", "Unholy Impale", "Splinters", "Raw Nova", "Raise", "Reap", "Hunger"}  # canon.md
CONCEPT_SPELLS = ["Raise", "Reap", "Hunger", "Grasp", "Swap", "Frenzy", "Rot", "Power of Below", "Splinters"]  # canon.md; Splinters' look is being redone
TONE_BANNED = ["sparkl", "chime", "twinkl", "cartoon", "laser", "sci-fi", "scifi", "arcade", "glitter", "fairy", "8-bit"]  # sound-designer.md
MUSIC_BANNED = ["phonk", "808", "trap beat", "drill"]  # audio-and-music.md: "No phonk for now"
ARTISTS_BANNED = ["nox cantabile", "requiem for wonderland", "fellowship", "world of warcraft", "blizzard",
                  "solo leveling", "pokemon", "pokémon", "greg rutkowski", "in the style of"]  # music-director.md, art-direction.md
IMPALE_GROUND = re.compile(r"\b(ground|earth|soil|underground|floor|sol)\b", re.I)  # canon.md: the spear forms in the air

PIPELINE_RULES = """

## Running inside the content pipeline
You run headless with no tools and no file access. Ignore any instruction above about editing files, trackers or
boards, calling other agents, or waiting for the designer. The game documents in the message are the source of truth
and win over anything in this role text. Never decide what open-questions.md leaves open: when you must assume
something, say so in the output. Reply with one JSON object and nothing else: no prose, no code fence.
"""

CRITIC_RULES = """

## Running inside the content pipeline
You run headless with no tools and no file access: ignore the instructions above about reviews.md and canon.md.
Review only the output in the message, against the documents in the message. Do not ask for content outside the task.
Reply with one JSON object and nothing else, in this shape:
{"verdict": "APPROVED | APPROVED WITH NOTES | CHANGES REQUIRED",
 "tone_score": 1-5,
 "tone_comment": "does this sound like Dark Touch and not like generic dark fantasy, in one sentence",
 "issues": [{"where": "item id or field", "what": "one sentence", "why": "the document and the rule it breaks",
             "severity": "blocking | should_fix | note",
             "kind": "contradiction | open_question | tone | preference"}]}
Only a real contradiction, or a tone failure against a written rule, may be blocking or should_fix. A preference is a
note. Something that quietly decides an open question is an open_question: blocking if it states it as settled, a note
if it is clearly marked as an assumption. Do not invent rules the documents do not contain.
"""


def read_source(rel):
    """Reads from the repository, or from the snapshot when Assignment-4 travels alone."""
    path = REPO / rel
    if not path.exists():
        path = SNAPSHOT / rel
    return path.read_text(encoding="utf-8-sig")


def snapshot(rel):
    source = REPO / rel
    if source.exists():
        target = SNAPSHOT / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)


def parse_agent(rel):
    """Returns (model alias, body) of a .claude/agents file."""
    text = read_source(rel)
    match = re.match(r"---\s*\n(.*?)\n---\s*\n(.*)", text, re.S)
    if not match:
        return "sonnet", text
    model = re.search(r"^model:\s*(\S+)", match.group(1), re.M)
    alias = model.group(1) if model else "sonnet"
    return ("sonnet" if alias == "inherit" else alias), match.group(2)


def documents(names):
    return "\n\n".join(f'<document name="{n}">\n{read_source(n)}\n</document>' for n in names)


def parse_json(raw):
    """Returns (object, error). Tolerates a code fence or stray text around one JSON object."""
    start, end = raw.find("{"), raw.rfind("}")
    if start < 0 or end <= start:
        return None, "the reply contains no JSON object"
    try:
        return json.loads(raw[start:end + 1]), None
    except json.JSONDecodeError as error:
        return None, f"invalid JSON: {error}"


def affirmed_hits(text, words):
    """The banned words used positively: 'no sparkles' or 'without chimes' does not count."""
    hits = []
    lowered = text.lower()
    for word in words:
        for match in re.finditer(re.escape(word), lowered):
            before = lowered[max(0, match.start() - 28):match.start()]
            if not re.search(r"\b(no|not|without|avoid|never|free of)\b", before):
                hits.append(word)
                break
    return hits


# --- deterministic rules: each returns a list of failures, empty means it passes ---

def check_sounds(data, rows):
    failures = []
    items = data.get("sounds")
    if not isinstance(items, list):
        return ["'sounds' is missing or is not a list"]
    by_id = {str(item.get("id")): item for item in items if isinstance(item, dict)}
    wanted = {row["ID"]: row for row in rows}
    for missing in sorted(set(wanted) - set(by_id)):
        failures.append(f"{missing}: this sound is missing")
    for extra in sorted(set(by_id) - set(wanted)):
        failures.append(f"{extra}: not one of the requested sounds")
    for sound_id, item in sorted(by_id.items()):
        row = wanted.get(sound_id)
        if not row:
            continue
        prompt = str(item.get("prompt", "")).strip()
        words = len(prompt.split())
        if not 12 <= words <= 60:
            failures.append(f"{sound_id}: prompt has {words} words, the rule is about 20-50")
        if not prompt.endswith("No music, no voice."):
            failures.append(f"{sound_id}: prompt must end with 'No music, no voice.'")
        if row["Boucle"] == "Oui" and "seamless loop" not in prompt.lower():
            failures.append(f"{sound_id}: looping sound without 'seamless loop'")
        for hit in affirmed_hits(prompt, TONE_BANNED):
            failures.append(f"{sound_id}: banned 'too fantasy' word: {hit}")
        duration = item.get("duration")
        if not isinstance(duration, (int, float)) or not 0.5 <= duration <= 30:
            failures.append(f"{sound_id}: duration {duration!r} is outside ElevenLabs' 0.5-30 s")
        influence = item.get("influence")
        if not isinstance(influence, (int, float)) or not 0 <= influence <= 1:
            failures.append(f"{sound_id}: influence {influence!r} is outside 0-1")
        element = row["Élément"]
        if row["Moment"] == "Début du cast" and element in CAST_TIMES and duration != CAST_TIMES[element]:
            failures.append(f"{sound_id}: {element} casts in {CAST_TIMES[element]} s (canon), the sound lasts {duration}")
        if element == "Splinters" and affirmed_hits(prompt, ["bone"]):
            failures.append(f"{sound_id}: Splinters are shards of cut tombstone (canon), not bone")
        if element == "Unholy Impale":
            ground =IMPALE_GROUND.search(prompt + " " + str(item.get("description_fr", "")))
            if ground and not affirmed_negation(prompt, ground.group(0)):
                failures.append(f"{sound_id}: the spear forms in the air (canon), nothing comes from the '{ground.group(0)}'")
    return failures


def affirmed_negation(text, word):
    return not affirmed_hits(text, [word.lower()]) and word.lower() in text.lower()


def check_music(data, _context):
    failures = []
    cues = data.get("cues")
    if not isinstance(cues, list):
        return ["'cues' is missing or is not a list"]
    by_id = {str(cue.get("id")): cue for cue in cues if isinstance(cue, dict)}
    for wanted in ("exploration", "combat", "boss", "raise_motif"):
        if wanted not in by_id:
            failures.append(f"{wanted}: this cue is missing")
    layers = [by_id[n] for n in ("exploration", "combat", "boss") if n in by_id]
    if len({str(cue.get("key")).lower() for cue in layers}) > 1:
        failures.append("the adaptive layers must share one key so they can crossfade")
    if len({cue.get("bpm") for cue in layers}) > 1:
        failures.append("the adaptive layers must share one tempo so they can crossfade")
    for cue_id, cue in by_id.items():
        prompt = str(cue.get("prompt", ""))
        if "cello" not in prompt.lower():
            failures.append(f"{cue_id}: the cello is always the lead, it is not in the prompt")
        for hit in affirmed_hits(prompt, MUSIC_BANNED):
            failures.append(f"{cue_id}: 'no phonk for now' (audio-and-music.md), the prompt asks for {hit}")
        for hit in affirmed_hits(prompt, ARTISTS_BANNED):
            failures.append(f"{cue_id}: names a reference in the prompt: {hit}")
    for layer in layers:
        if layer.get("loop") is not True:
            failures.append(f"{layer.get('id')}: adaptive layers must loop")
    motif = by_id.get("raise_motif")
    if motif:
        trim = motif.get("final_trim_s")
        if not isinstance(trim, (int, float)) or not 2 <= trim <= 8:
            failures.append(f"raise_motif: final_trim_s {trim!r}, the rule is the strongest 2-8 s")
    return failures


def check_section(data, tier):
    failures = []
    fights = data.get("fights")
    if not isinstance(fights, list):
        return ["'fights' is missing or is not a list"]
    if not 4 <= len(fights) <= 6:
        failures.append(f"{len(fights)} fights, a section holds about 5")
    for field in ("exit", "chests", "layout_areas"):
        if not data.get(field):
            failures.append(f"'{field}' is empty")
    allowed_ranks = {rank.capitalize() for rank in ("shadow", "asset", "ace", "general") if tier.get(rank, 0) > 0}
    for index, fight in enumerate(fights, 1):
        total = 0
        for group in fight.get("enemies", []):
            total += int(group.get("count", 0))
            if group.get("type") not in ROSTER:
                failures.append(f"fight {index}: '{group.get('type')}' is not in the roster")
            if group.get("rank") not in allowed_ranks:
                failures.append(f"fight {index}: rank '{group.get('rank')}' cannot appear at tier {tier['tier']}")
        if not tier["enemiesMin"] <= total <= tier["enemiesMax"]:
            failures.append(f"fight {index}: {total} enemies, tier {tier['tier']} allows {tier['enemiesMin']}-{tier['enemiesMax']}")
        if not str(fight.get("teaches", "")).strip():
            failures.append(f"fight {index}: does not say what it teaches")
        for spell in fight.get("spells_needed", []):
            if spell not in STARTING_SPELLS:
                failures.append(f"fight {index}: '{spell}' is not one of the 7 spells known at the start")
    return failures


def check_concepts(data, _context):
    failures = []
    items = data.get("spells")
    if not isinstance(items, list):
        return ["'spells' is missing or is not a list"]
    by_name = {str(item.get("spell")): item for item in items if isinstance(item, dict)}
    for spell in CONCEPT_SPELLS:
        if spell not in by_name:
            failures.append(f"{spell}: this spell is missing")
    for spell, item in by_name.items():
        prompt = str(item.get("prompt", ""))
        words = len(prompt.split())
        if not 40 <= words <= 130:
            failures.append(f"{spell}: prompt has {words} words, the rule is 40-130")
        if not re.search(r"cyan|turquoise", prompt, re.I):
            failures.append(f"{spell}: the arm's cyan-turquoise is the game's signature, it is not in the prompt")
        if "stylised" not in prompt.lower() and "stylized" not in prompt.lower():
            failures.append(f"{spell}: the art direction is stylised, the prompt does not say so")
        if affirmed_hits(re.sub(r"olive[- ]green", "", prompt, flags=re.I), ["green"]):
            failures.append(f"{spell}: 'verdâtre' means the arm's cyan-turquoise, the prompt asks for green")
        for hit in affirmed_hits(prompt, ARTISTS_BANNED):
            failures.append(f"{spell}: names a reference in the prompt: {hit}")
    return failures


# --- the targets ---

def sound_rows():
    text = read_source(SOUND_TRACKER)
    return list(csv.DictReader(text.splitlines(), delimiter=";"))


def rows_to_generate():
    return [row for row in sound_rows() if row["Statut"] == "À générer" and row["Prompt ElevenLabs"].strip()]


def tier_one():
    return json.loads(read_source("Assignment-4/inputs/rank_odds_tier1.json"))


def sounds_task():
    brief = [{"id": r["ID"], "category": r["Catégorie"], "element": r["Élément"], "moment": r["Moment"],
              "loops": r["Boucle"] == "Oui", "current_description_fr": r["Description"]} for r in rows_to_generate()]
    return ("Write one ElevenLabs sound-effect prompt for each sound below. The current descriptions are old drafts: "
            "where a game document contradicts one, follow the document.\n" + json.dumps(brief, ensure_ascii=False, indent=1) +
            '\n\nReturn {"sounds": [{"id": "SND-000", "description_fr": "one French sentence: what the player must feel", '
            '"prompt": "English prompt", "duration": 1.0, "influence": 0.4, "variants": 1}]} with one entry per sound.')


MUSIC_TASK = ("Write the generation prompts for the four cues Dark Touch needs: the three adaptive layers of the level "
              "(exploration, combat, boss) and the signature raise-a-soldier motif. Write prompts only; nothing is generated here.\n\n"
              'Return {"cues": [{"id": "exploration | combat | boss | raise_motif", "use": "when it plays", "tool": "ElevenLabs Music", '
              '"prompt": "English prompt", "key": "D minor", "bpm": 72, "duration_s": 120, "loop": true, "final_trim_s": null, '
              '"listen_for": "one sentence on what the designer should listen for"}]}. For raise_motif, generate about 30 s, '
              'set loop to false and final_trim_s to the length of the strongest part to keep.')


def section_task():
    return ("Design section 1 of the demo level, at difficulty tier 1. It is the first thing a new player meets, so it teaches the "
            "kit one piece at a time with no separate tutorial, and the player knows only the 7 starting spells. Tier 1 numbers from "
            "the Rank Odds board, which you must obey in every fight including the first:\n" + json.dumps(tier_one()) +
            "\nThis section is the story's opening: on Cel'ardor, at war, the half-dragonkin raids the enemy army before it can reach the "
            "small town, learning to use the arm the pact gave him. Name and stage the places from that, so they could not belong to another "
            "game, without inventing factions, the entity or the causes of the war. "
            "\nYou choose which enemy types appear and how they are placed. Mark as an assumption anything open-questions.md leaves "
            'open, such as what marks the exit or where chests go.\n\nReturn {"section": 1, "tier": 1, "layout_areas": ["..."], '
            '"fights": [{"id": 1, "area": "...", "enemies": [{"type": "Guard", "count": 2, "rank": "Shadow"}], "placement": "...", '
            '"teaches": "...", "spells_needed": ["Deathbolt"], "readability": "what the camera must see"}], "exit": "...", '
            '"chests": [{"area": "...", "why": "..."}], "assumptions": ["..."]}.')


def concept_task():
    ideas = (INPUTS / "spell_ideas.md").read_text(encoding="utf-8-sig")
    return ("Write one GPT-image concept-art prompt for each of these spells: " + ", ".join(CONCEPT_SPELLS) + ". The designer described "
            "what he imagines below: keep his idea, develop it, never replace it.\n<designer_ideas>\n" + ideas + "\n</designer_ideas>\n\n"
            'Return {"spells": [{"spell": "Raise", "designer_idea": "his words, short", "prompt": "English prompt, 40-130 words", '
            '"aspect": "16:9"}]}.')


TARGETS = {
    "sounds": {"agent": f"{AGENTS}/sound-designer.md", "task": sounds_task, "check": check_sounds, "context": rows_to_generate,
               "docs": [f"{DOCS}/canon.md", f"{DOCS}/lore.md", f"{DOCS}/audio-and-music.md"]},
    "music": {"agent": f"{AGENTS}/music-director.md", "task": lambda: MUSIC_TASK, "check": check_music, "context": lambda: None,
              "docs": [f"{DOCS}/canon.md", f"{DOCS}/lore.md", f"{DOCS}/audio-and-music.md"]},
    "section1": {"agent": f"{AGENTS}/level-designer.md", "task": section_task, "check": check_section, "context": tier_one,
                 "docs": [f"{DOCS}/canon.md", f"{DOCS}/lore.md", f"{DOCS}/open-questions.md", f"{DOCS}/GDD.md"]},
    "concepts": {"agent": "Assignment-4/agents/concept-artist.md", "task": concept_task, "check": check_concepts, "context": lambda: None,
                 "docs": [f"{DOCS}/canon.md", f"{DOCS}/lore.md", f"{DOCS}/art-direction.md"]},
}
CRITIC_DOCS = [f"{DOCS}/canon.md", f"{DOCS}/lore.md", f"{DOCS}/open-questions.md", f"{DOCS}/audio-and-music.md", f"{DOCS}/art-direction.md", f"{DOCS}/GDD.md"]


# --- talking to the model ---

class LiveModel:
    def __init__(self):
        self.claude = shutil.which("claude")
        if not self.claude:
            sys.exit("The `claude` CLI was not found. Install Claude Code and log in, or run with --replay.")
        self.cost = 0.0
        self.lock = threading.Lock()

    def __call__(self, step, model, system, prompt):
        # Outside the repository, so the project's hooks and CLAUDE.md never run for these calls.
        with tempfile.TemporaryDirectory() as work:
            system_file = Path(work) / "system.md"
            system_file.write_text(system, encoding="utf-8")
            command = [self.claude, "-p", "--model", model, "--tools", "", "--strict-mcp-config", "--no-session-persistence",
                       "--output-format", "json", "--system-prompt-file", str(system_file)]
            last_error = ""
            for _ in range(2):
                result = subprocess.run(command, input=prompt, capture_output=True, text=True, encoding="utf-8", cwd=work, timeout=1200)
                if result.returncode == 0:
                    reply = json.loads(result.stdout)
                    if not reply.get("is_error"):
                        with self.lock:
                            self.cost += float(reply.get("total_cost_usd") or 0)
                        record(step, model, system, prompt, reply)
                        return reply["result"]
                    last_error = str(reply.get("result"))
                else:
                    last_error = (result.stderr or result.stdout)[-800:]
            raise RuntimeError(f"{step}: the claude CLI failed twice: {last_error}")


class ReplayModel:
    cost = 0.0

    def __call__(self, step, model, system, prompt):
        path = RECORDINGS / f"{step}.txt"
        if not path.exists():
            raise RuntimeError(f"no recording for {step}: run live first")
        return path.read_text(encoding="utf-8")


RECORD_LOCK = threading.Lock()


def record(step, alias, system, prompt, reply):
    """Keeps the full trace of a model call: what was sent, what came back, which model answered, what it cost."""
    RECORDINGS.mkdir(parents=True, exist_ok=True)
    (RECORDINGS / f"{step}.txt").write_text(reply["result"], encoding="utf-8")
    (RECORDINGS / f"{step}.request.md").write_text(f"# Request: {step}\n\nModel alias: {alias}\n\n## System prompt\n\n{system}\n\n## Message\n\n{prompt}\n", encoding="utf-8")
    entry = {"step": step, "time": datetime.now().isoformat(timespec="seconds"), "alias": alias, "models": sorted(reply.get("modelUsage", {})),
             "cost_usd": reply.get("total_cost_usd"), "duration_ms": reply.get("duration_ms"), "session_id": reply.get("session_id"),
             "prompt_chars": len(prompt), "reply_chars": len(reply["result"])}
    with RECORD_LOCK, open(RECORDINGS / "index.jsonl", "a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry) + "\n")


# --- the loop ---

def critic_prompt(name, output, failures):
    return (documents(CRITIC_DOCS) + f"\n\nReview this generated content for Dark Touch (target: {name}). It is a proposal for the "
            "designer.\n<output>\n" + json.dumps(output, ensure_ascii=False, indent=1) + "\n</output>\n\nThe automatic rule check reported: " +
            (json.dumps(failures, ensure_ascii=False) if failures else "no failure") + "\nDo not repeat those failures as issues.")


def run_critic(name, step, output, failures, model):
    role = parse_agent(CRITIC_AGENT)[1] + CRITIC_RULES
    review, error = parse_json(model(step, CRITIC_MODEL, role, critic_prompt(name, output, failures)))
    if error:
        return {"verdict": "INVALID", "issues": [{"where": "critic", "what": f"the critic reply was unusable: {error}", "why": "pipeline",
                                                  "severity": "blocking", "kind": "contradiction"}]}
    review.setdefault("issues", [])
    return review


def blocking_issues(review):
    return [issue for issue in review.get("issues", []) if issue.get("severity") in BLOCKING]


def run_target(name, target, model, max_rounds, log=print):
    alias, role = parse_agent(target["agent"])
    system = role + PIPELINE_RULES
    base = documents(target["docs"]) + "\n\n# Task\n" + target["task"]()
    context = target["context"]()
    journal = {"target": name, "agent": target["agent"], "generator_model": alias, "critic_model": CRITIC_MODEL, "rounds": []}
    output, problems = None, []
    for number in range(1, max_rounds + 1):
        prompt = base
        if output is not None or problems:
            prompt += ("\n\n# Revise\nYour previous version:\n" + json.dumps(output, ensure_ascii=False, indent=1) +
                       "\n\nFix every problem below and change nothing else:\n" + "\n".join(f"- {p}" for p in problems))
        candidate, error = parse_json(model(f"{name}_generate_{number}", alias, system, prompt))
        if candidate is not None:
            output = candidate
        failures = [error] if error else target["check"](candidate, context)
        review = run_critic(name, f"{name}_critic_{number}", output, failures, model) if candidate is not None else {"verdict": "SKIPPED", "issues": []}
        blocking = blocking_issues(review)
        journal["rounds"].append({"round": number, "rule_failures": failures, "critic": review})
        log(f"[{name}] round {number}: {len(failures)} rule failures, {len(blocking)} blocking critic issues, verdict {review.get('verdict')}")
        problems = [f"Rule: {f}" for f in failures] + [f"Critic on {i.get('where')}: {i.get('what')} ({i.get('why')})" for i in blocking]
        tone = review.get("tone_score")
        if isinstance(tone, (int, float)) and tone < MIN_TONE:
            problems.append(f"Critic on tone, {tone}/5 (at least {MIN_TONE} is required): {review.get('tone_comment')} Make it sound like Dark Touch, using only what the documents establish.")
        if not problems:
            journal["status"] = "APPROVED"
            break
    else:
        journal["status"] = "NEEDS_DESIGNER"
        journal["unresolved"] = problems
    journal["output"] = output
    return journal


def audit_tracker(model, log=print):
    """Reviews what sons.csv already holds, before regenerating: shows what the loop would have caught."""
    rows = [row for row in sound_rows() if row["Prompt ElevenLabs"].strip() and (row["Statut"] == "À générer" or row["Élément"] == "Unholy Impale")]
    existing = {"sounds": [{"id": r["ID"], "element": r["Élément"], "moment": r["Moment"], "status": r["Statut"], "description_fr": r["Description"],
                            "prompt": r["Prompt ElevenLabs"].strip(), "duration": to_number(r["Durée (s)"]), "influence": to_number(r["Influence du prompt"])} for r in rows]}
    failures = check_sounds(existing, rows)
    review = run_critic("the sound prompts already in the tracker, written before this pipeline existed", "audit_critic_1", existing, failures, model)
    log(f"[audit] {len(rows)} existing rows: {len(failures)} rule failures, {len(blocking_issues(review))} blocking critic issues")
    return {"target": "audit of review/sons.csv", "rows": len(rows), "rule_failures": failures, "critic": review}


def to_number(text):
    try:
        return float(text.replace(",", "."))
    except (ValueError, AttributeError):
        return None


# --- writing the results ---

def write_sounds(journal):
    wanted = {row["ID"]: row for row in rows_to_generate()}
    columns = ["ID", "Élément", "Moment", "Description", "Prompt ElevenLabs", "Durée (s)", "Influence du prompt", "Boucle", "Variantes", "Nom de fichier"]
    with open(OUTPUTS / "1_sound_prompts.csv", "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(columns)
        for item in journal["output"].get("sounds", []):
            row = wanted.get(str(item.get("id")))
            if row:
                writer.writerow([row["ID"], row["Élément"], row["Moment"], item.get("description_fr"), item.get("prompt"), item.get("duration"),
                                 item.get("influence"), row["Boucle"], item.get("variants"), row["Nom de fichier"]])


def write_music(journal):
    lines = ["# Music prompts: Dark Touch", "", f"Status: {journal['status']}. Proposals for the designer; nothing was generated.", ""]
    for cue in journal["output"].get("cues", []):
        lines += [f"## {cue.get('id')}", "", f"- **Use:** {cue.get('use')}", f"- **Tool:** {cue.get('tool')}", f"- **Key / tempo:** {cue.get('key')}, {cue.get('bpm')} BPM",
                  f"- **Length:** {cue.get('duration_s')} s, loop: {cue.get('loop')}" + (f", keep the strongest {cue.get('final_trim_s')} s" if cue.get("final_trim_s") else ""),
                  f"- **Listen for:** {cue.get('listen_for')}", "", "```text", str(cue.get("prompt")), "```", ""]
    (OUTPUTS / "2_music_prompts.md").write_text("\n".join(lines), encoding="utf-8")


def write_section(journal):
    data = journal["output"]
    lines = ["# Section 1 plan: Dark Touch, tier 1", "", f"Status: {journal['status']}. A proposal for the designer.", "", "## Areas", ""]
    lines += [f"- {area}" for area in data.get("layout_areas", [])] + ["", "## Fights", "", "| # | Area | Enemies | Teaches | Spells needed | Placement | Readability |", "| --- | --- | --- | --- | --- | --- | --- |"]
    for fight in data.get("fights", []):
        enemies = ", ".join(f"{g.get('count')} {g.get('type')} ({g.get('rank')})" for g in fight.get("enemies", []))
        lines.append(f"| {fight.get('id')} | {fight.get('area')} | {enemies} | {fight.get('teaches')} | {', '.join(fight.get('spells_needed', []))} | {fight.get('placement')} | {fight.get('readability')} |")
    lines += ["", "## Exit", "", str(data.get("exit")), "", "## Chests", ""] + [f"- **{c.get('area')}:** {c.get('why')}" for c in data.get("chests", [])]
    lines += ["", "## Assumptions (open questions, not decided)", ""] + [f"- {a}" for a in data.get("assumptions", [])] + [""]
    (OUTPUTS / "3_section_1_plan.md").write_text("\n".join(lines), encoding="utf-8")


def write_concepts(journal):
    lines = ["# Spell concept-art prompts: Dark Touch", "", f"Status: {journal['status']}. For GPT image generation.", ""]
    for item in journal["output"].get("spells", []):
        lines += [f"## {item.get('spell')}", "", f"**Designer's idea:** {item.get('designer_idea')}", "", f"**Aspect:** {item.get('aspect')}", "", "```text", str(item.get("prompt")), "```", ""]
    (OUTPUTS / "4_spell_concept_prompts.md").write_text("\n".join(lines), encoding="utf-8")


WRITERS = {"sounds": write_sounds, "music": write_music, "section1": write_section, "concepts": write_concepts}


def issue_lines(review):
    lines = []
    for issue in review.get("issues", []):
        lines.append(f"- **{issue.get('severity')} / {issue.get('kind')}** on `{issue.get('where')}`: {issue.get('what')} *({issue.get('why')})*")
    return lines or ["- nothing raised"]


def write_report(audit, journals, mode):
    lines = ["# What the checks and the critic caught", "", f"Generated by `pipeline.py` ({mode}) on {datetime.now():%Y-%m-%d %H:%M}.", ""]
    if audit:
        lines += ["## Audit of the sound prompts written before the pipeline", "", f"{audit['rows']} rows reviewed.", "", "### Rule failures", ""]
        lines += [f"- {f}" for f in audit["rule_failures"]] or ["- none"]
        lines += ["", f"### Critic: {audit['critic'].get('verdict')}, tone {audit['critic'].get('tone_score')}/5", "", str(audit["critic"].get("tone_comment")), ""] + issue_lines(audit["critic"]) + [""]
    for journal in journals:
        lines += [f"## {journal['target']}: {journal['status']}", "", f"Generator: `{journal['agent']}` ({journal['generator_model']}). Critic: Game Director ({journal['critic_model']}).", ""]
        for item in journal["rounds"]:
            critic = item["critic"]
            lines += [f"### Round {item['round']}: critic verdict {critic.get('verdict')}, tone {critic.get('tone_score')}/5", "", str(critic.get("tone_comment")), "", "Rule failures:", ""]
            lines += [f"- {f}" for f in item["rule_failures"]] or ["- none"]
            lines += ["", "Critic issues:", ""] + issue_lines(critic) + [""]
        if journal.get("unresolved"):
            lines += ["**Still open after the last round:**", ""] + [f"- {p}" for p in journal["unresolved"]] + [""]
    (OUTPUTS / "critic_report.md").write_text("\n".join(lines), encoding="utf-8")


# --- self test: no model involved ---

GOOD_SOUND = {"sounds": [{"id": "SND-T", "description_fr": "Une force froide se forme dans l'air.", "prompt": "A cold necrotic charge gathering in the air above a shoulder: low rising hum, dry crackle of ash and a breath-like swell, close and dry. No music, no voice.", "duration": 2.0, "influence": 0.4, "variants": 1}]}
TEST_ROWS = [{"ID": "SND-T", "Élément": "Unholy Impale", "Moment": "Début du cast", "Boucle": "Non"}]
TEST_TIER = {"tier": 1, "enemiesMin": 2, "enemiesMax": 3, "shadow": 100, "asset": 0, "ace": 0, "general": 0}


def good_section():
    fight = {"enemies": [{"type": "Guard", "count": 2, "rank": "Shadow"}], "teaches": "aim", "spells_needed": ["Deathbolt"]}
    return {"fights": [dict(fight) for _ in range(5)], "exit": "x", "chests": ["x"], "layout_areas": ["x"]}


def good_music():
    cue = lambda n: {"id": n, "prompt": "Solo cello lead, minor key, low drones", "key": "D minor", "bpm": 70, "loop": True}
    return {"cues": [cue("exploration"), cue("combat"), cue("boss"), {"id": "raise_motif", "prompt": "Solo cello motif", "loop": False, "final_trim_s": 5}]}


def self_test():
    results = []

    def expect(label, condition):
        results.append(condition)
        print(("PASS " if condition else "FAIL ") + label)

    expect("a good sound passes", check_sounds(GOOD_SOUND, TEST_ROWS) == [])
    bad = json.loads(json.dumps(GOOD_SOUND))
    bad["sounds"][0]["prompt"] = "A massive bone spear bursting out of the ground with magical sparkles and enough words to pass the length rule here. No music, no voice."
    failures = check_sounds(bad, TEST_ROWS)
    expect("a spear from the ground is caught", any("forms in the air" in f for f in failures))
    expect("a 'too fantasy' word is caught", any("sparkl" in f for f in failures))
    bad["sounds"][0].update(prompt=GOOD_SOUND["sounds"][0]["prompt"], duration=5)
    expect("a wrong cast time is caught", any("casts in" in f for f in check_sounds(bad, TEST_ROWS)))
    expect("a negated word does not count", affirmed_hits("no sparkles, no chimes", TONE_BANNED) == [])
    expect("a missing sound is caught", any("missing" in f for f in check_sounds({"sounds": []}, TEST_ROWS)))
    expect("good music passes", check_music(good_music(), None) == [])
    bad = good_music()
    bad["cues"][0]["prompt"] = "Solo cello lead with heavy phonk 808 drums"
    expect("phonk is caught", any("phonk" in f for f in check_music(bad, None)))
    bad = good_music()
    bad["cues"][1]["prompt"] = "Violin lead"
    expect("a missing cello is caught", any("cello" in f for f in check_music(bad, None)))
    bad = good_music()
    bad["cues"][2]["bpm"] = 120
    expect("layers out of tempo are caught", any("tempo" in f for f in check_music(bad, None)))
    expect("a good section passes", check_section(good_section(), TEST_TIER) == [])
    bad = good_section()
    bad["fights"][0]["enemies"] = [{"type": "Dragon", "count": 9, "rank": "General"}]
    failures = check_section(bad, TEST_TIER)
    expect("an unknown type, a banned rank and too many enemies are caught", len(failures) == 3)
    bad = good_section()
    bad["fights"][1]["spells_needed"] = ["Grasp"]
    expect("a spell not yet known is caught", any("Grasp" in f for f in check_section(bad, TEST_TIER)))
    bad_spell = {"spells": [{"spell": s, "prompt": "A spell in the style of Blizzard"} for s in CONCEPT_SPELLS]}
    failures = check_concepts(bad_spell, None)
    expect("a concept prompt naming a studio, without cyan or style, is caught", len(failures) >= 24)
    green = {"spells": [{"spell": "Rot", "prompt": "stylised cyan arm, sickly green veins"}]}
    expect("a true green is caught", any("green" in f for f in check_concepts(green, None)))
    olive = {"spells": [{"spell": "Rot", "prompt": "stylised cyan arm, olive-green mantle"}]}
    expect("the hero's olive-green mantle is allowed", not any("asks for green" in f for f in check_concepts(olive, None)))
    expect("broken JSON is reported", parse_json("not json")[1] is not None)

    # The loop itself, with a scripted model.
    target = {"agent": CRITIC_AGENT, "task": lambda: "test", "check": lambda data, _: ["Rule broken"] if data.get("bad") else [], "context": lambda: None, "docs": []}

    def scripted(replies):
        calls = []

        def model(step, _model, _system, prompt):
            calls.append((step, prompt))
            return replies[step] if step in replies else '{"verdict": "APPROVED", "issues": []}'
        model.calls = calls
        return model

    silent = lambda _text: None
    model = scripted({"t_generate_1": '{"bad": true}', "t_generate_2": '{"bad": false}'})
    journal = run_target("t", target, model, 3, silent)
    expect("a rule failure sends it back and the fix is approved", journal["status"] == "APPROVED" and len(journal["rounds"]) == 2)
    expect("the failure reaches the generator's revision prompt", "Rule broken" in dict(model.calls)["t_generate_2"])
    critic_says_no = '{"verdict": "CHANGES REQUIRED", "issues": [{"where": "x", "what": "Wrong people", "why": "lore.md", "severity": "blocking", "kind": "contradiction"}]}'
    model = scripted({"t_generate_1": '{"bad": false}', "t_generate_2": '{"bad": false}', "t_critic_1": critic_says_no})
    journal = run_target("t", target, model, 3, silent)
    expect("a blocking critic issue sends it back", journal["status"] == "APPROVED" and "Wrong people" in dict(model.calls)["t_generate_2"])
    note = '{"verdict": "APPROVED WITH NOTES", "issues": [{"where": "x", "what": "Could be nicer", "why": "taste", "severity": "note", "kind": "preference"}]}'
    model = scripted({"t_generate_1": '{"bad": false}', "t_critic_1": note})
    expect("a note does not block", run_target("t", target, model, 3, silent)["status"] == "APPROVED")
    flat = '{"verdict": "APPROVED", "tone_score": 2, "tone_comment": "Generic dark fantasy.", "issues": []}'
    model = scripted({"t_generate_1": '{"bad": false}', "t_generate_2": '{"bad": false}', "t_critic_1": flat})
    journal = run_target("t", target, model, 3, silent)
    expect("a tone score below the minimum sends it back", len(journal["rounds"]) == 2 and "Generic dark fantasy" in dict(model.calls)["t_generate_2"])
    model = scripted({f"t_generate_{n}": '{"bad": true}' for n in (1, 2, 3)})
    journal = run_target("t", target, model, 3, silent)
    expect("the loop stops after 3 rounds and hands over to the designer", journal["status"] == "NEEDS_DESIGNER" and len(journal["rounds"]) == 3)
    print(f"{sum(results)}/{len(results)} self-tests passed")
    return all(results)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--replay", action="store_true", help="use the recorded model replies instead of calling the model")
    parser.add_argument("--self-test", action="store_true", help="test the rules and the loop without any model")
    parser.add_argument("--targets", default="sounds,music,section1,concepts", help="comma-separated targets")
    parser.add_argument("--max-rounds", type=int, default=3)
    parser.add_argument("--no-audit", action="store_true", help="skip the audit of the existing sound tracker")
    args = parser.parse_args()
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    if args.self_test:
        return 0 if self_test() else 1

    names = [name.strip() for name in args.targets.split(",") if name.strip()]
    if "concepts" in names and not (INPUTS / "spell_ideas.md").exists():
        print("[concepts] skipped: inputs/spell_ideas.md does not exist yet")
        names.remove("concepts")
    global OUTPUTS
    if args.replay:
        OUTPUTS = HERE / "outputs_replay"  # The live results stay untouched and can be compared.
    model = ReplayModel() if args.replay else LiveModel()
    if not args.replay:
        for rel in {CRITIC_AGENT, SOUND_TRACKER, "Assignment-4/inputs/rank_odds_tier1.json", *CRITIC_DOCS, *(TARGETS[n]["agent"] for n in names)}:
            snapshot(rel)
    OUTPUTS.mkdir(exist_ok=True)

    audit = None
    journals = {}
    failed = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        audit_job = None if args.no_audit else pool.submit(audit_tracker, model)
        jobs = {pool.submit(run_target, name, TARGETS[name], model, args.max_rounds): name for name in names}
        for job in concurrent.futures.as_completed(jobs):
            name = jobs[job]
            try:
                journals[name] = job.result()
            except Exception:  # A target that crashes must be reported, and must not pass for a success.
                failed.append(name)
                traceback.print_exc()
        if audit_job:
            try:
                audit = audit_job.result()
            except Exception:
                failed.append("audit")
                traceback.print_exc()

    for name, journal in journals.items():
        if journal.get("output") is not None:
            WRITERS[name](journal)
    ordered = [journals[name] for name in names if name in journals]
    write_report(audit, ordered, "replay of recorded replies" if args.replay else "live")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S") + ("-replay" if args.replay else "")
    run_dir = RUNS / stamp
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "journal.json").write_text(json.dumps({"audit": audit, "targets": ordered}, ensure_ascii=False, indent=1), encoding="utf-8")

    print("\nSummary")
    for journal in ordered:
        print(f"  {journal['target']}: {journal['status']} after {len(journal['rounds'])} round(s)")
    for name in failed:
        print(f"  {name}: CRASHED")
    print(f"Outputs: {OUTPUTS}\nJournal: {run_dir / 'journal.json'}")
    if args.replay:
        for live in sorted((HERE / "outputs").glob("[0-9]_*")):
            print(f"  {live.name}: " + ("identical to the live run" if filecmp.cmp(live, OUTPUTS / live.name, shallow=False) else "DIFFERENT from the live run"))
    if not args.replay:
        print(f"Model cost (as reported by the CLI): ${model.cost:.2f}")
    return 1 if failed or not ordered else 0


if __name__ == "__main__":
    sys.exit(main())
