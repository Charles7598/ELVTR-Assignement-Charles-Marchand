# Dark Touch — Art Direction

Part of the [Dark Touch GDD](GDD.md). Decisions only; open points are in [Open questions](open-questions.md).

## Style

Stylised, in the spirit of **Fellowship**. The world is Cel'ardor, a continent at war (see [Lore](lore.md)).

## Pipeline

1. Concept images created with GPT image generation.
2. 3D characters generated from those images with **Meshy AI**.
3. Characters rigged to the UE5 Mannequin skeleton (see below).

## Skeleton and character setup

- **Every character uses the UE5 Mannequin skeleton**, so animations are shared without retargeting.
- **The player is one skeletal mesh** on that same skeleton (designer, 2026-11-02; it used to be body + arm as two meshes). The cursed arm has its own material slot "Arm", so it still gets its own material and effects without touching the body.
- **Cloak:** only the long hanging strips are simulated cloth; the hood and the shoulder cloth follow the skin, never the simulation (designer, 2026-11-02).

### The main character

Validated concept (front and back), the reference for the 3D model:

<img src="images/main-character.png" alt="Main character concept, front and back" width="560">

- **Hood** with two small golden horns; **ornate golden mask** with glowing cyan eyes, the face lost in shadow.
- **Tattered olive-green mantle** over the shoulders, longer at the back, down to the waist.
- **Dark brown leather armour** with thin gold trims; **golden chains** across the chest and kept short and tight at the belt.
- **No long coat:** the outfit stops at the belt. Below it, only fitted leather trousers with buckled straps and wrapped leather boots, so the legs need no cloth animation.
- **Athletic build**, close to the UE5 Manny proportions, so the rig and shared animations fit with little clipping.
- **Left arm:** normal, in a dark leather glove. **Right arm:** the dark-magic arm, in **cyan-turquoise**, matching the eyes.
- Only the mantle may need light physics (one Kawaii Physics or AnimDynamics chain on its back strips).

### Enemy references

Validated mood references for four enemy types (also the soldier versions, since enemies and soldiers share the roster). They set the look; the 3D models are generated from a clean turnaround made from them. The images are third-party art kept locally for reference only (not committed).

| Type | Reference | Key traits |
| --- | --- | --- |
| Berserker | `images/references/berserker.jpg` | Bull warrior, massive black bull-headed brute (minotaur): huge horns, double-bladed axe, glowing red runes, bull skull at the belt, torn red loincloth, spiked bracers and greaves |
| Mage | `images/references/mage.jpg` | Draconic mage: blue-and-white scaled dragon head and hands, navy and cream robe with geometric trims, staff topped with a blue crystal, blue spell glow in the free hand |
| Blademaster | `images/references/blademaster.jpg` | Dark ornate plate armour, closed helm, white fur collar, tattered cloak, long two-handed greatsword stained with blood |
| Tank | `images/references/tank.jpg` | A bull warrior (like the Berserker) in the reference's armour: bull head and horns under or through the helm; heavy spiked grey plate armour, torn red cape and tabard, large shield with a red dragon emblem, sword with glowing red veins (the war banner is a prop, optional) |

For the Mannequin skeleton: keep human proportions under the look. **Bull warriors (Berserker, Tank) keep their hooves** (designer, 2026-10-29): the legs keep a human shape and human joints down to the ankle, and each ends in a large cloven hoof sitting flat under the ankle, its bottom acting as heel and sole. At skinning, the whole hoof is weighted 100% to the `foot` bone; the toe bones (`ball_l`, `ball_r`) stay in the skeleton for the shared animations but carry no weight, so the hoof stays rigid. The Mage's clawed digitigrade feet become plantigrade feet in the turnaround; horns, tails of cloth and capes are fine but kept short below the hips; weapons, shields and staffs are separate meshes attached to the hand sockets.

## The weapon: the dark-magic arm

The player fights without a blade. The right arm is not physical: it is pure dark magic, translucent and glowing **cyan-turquoise**, made of swirling spectral energy that drifts off as wisps and particles, with long clawed fingers. Although it is not flesh, it acts like a real arm: it can **strike, grab and hold things**, which is how it casts, raises and reaps.

<img src="images/arm-reference.png" alt="Reference: the spectral dark-magic arm" width="320">

*Early reference for the arm's shape and effects; its colour is now cyan-turquoise, as in the main character concept.*

It is the game's visual signature and **must stand out in every animation**: casting, raising, reaping and idle all need a distinctive effect on the arm.

## Environment assets

Level assets (rocks, trees, ruins, war camp and village props, chests, ground, sky) are stylised and slightly desaturated so characters and the cyan arm pop. They are found by the [Environment Scraper](agents/environment-scraper.md) and reviewed on the [Environment Board](https://claude.ai/artifact/5TxnhfWgdumWg5oXVUhABd).

## Readability palettes

**Enemies are warm and alive; summons are cold and spectral.** Warm against cool reads fastest, and orange against cyan stays clear for colour-blind players. Each type uses one mesh with one material: a "Raised" parameter switches it from the enemy palette to the summon palette and lights up the cyan glow.

| Enemies (living) | Hex | Summons (raised) | Hex |
| --- | --- | --- | --- |
| Tabards and cloth: burnt orange | `#C8641E` | Body and armour: slate grey | `#5E6670` |
| Secondary cloth: ivory | `#E8DCC0` | Cloth: ashen blue-grey | `#3E4650` |
| Armour: warm steel | `#9A9590` | Skin: corpse pale | `#A9B0B0` |
| Leather: tan | `#8A5A34` | Eyes, veins, cracks (emissive): the arm's cyan | `#3FE0D0` |
| Skin: warm flesh | `#C99A7A` | | |

- Summons share the player's cyan, so they read as his. The main character (dark brown, olive, gold) reads as neither.
- Elites keep the enemy palette, richer: darker, more saturated orange, heavier dark-bronze armour, bigger trims.
- Check: an enemy and a summon side by side must stay distinct in black and white.

## Rank colours

Each rank has a colour:

| Rank | Colour |
| --- | --- |
| Shadow | Pale green |
| Asset | Purple |
| Ace | Black, with a thin silver edge so it reads on dark shapes |
| General | Deep red with a black outline, kept distinct from the enemies' orange |

- **On enemies:** no effect on the body. The rank shows on the **health bar**, styled like the default modern WoW (retail) nameplate health bar, with no add-ons. **Elites** get a **gold outline** on their health bar.
- **On corpses:** a **faint aura**, weaker than on summons but still visible, so the player can scan the battlefield for good ranks. Aiming at a corpse opens a world widget above it with its name, rank and stat grades (gold outline for elites); holding **Alt** shows every health bar and corpse widget at once.
- **On summons:** the rank is an **aura**, an overlay on the skeletal mesh material plus a little smoke. It **dominates the summon palette** and is more visible than the base material.

## Elites

Any mob can be an elite: it has an aura, a slightly different colour palette, and a stat boost over the normal version. A raised elite is captured and sent to the army at the base.
