# Dark Touch — Lore

Part of the [Dark Touch GDD](GDD.md). Simple for now; to be expanded later. Magic, peoples and the player's origin validated by the designer on 2026-10-29.

## The world

**Cel'ardor** (working name). The whole continent is at war.

## The story

You are a half-breed, part dragonkin and part human, who lost an arm and had never wielded magic. You accepted a pact with a dark entity you know little about. It gave you a magic arm that casts spells on its own, granting you the powers of a necromancer. The arm is your first magic.

You wake up in a small town. To protect the village, you raid the enemy army before it can attack. You know you must learn magic from scratch with this new power, so you are glad to start by protecting a small village, and later bring destruction to your enemies once you have mastered it.

## Magic

- **Only the dragonkin can wield magic:** elemental, arcane and dark magic alike.
- **A human body cannot withstand magic.** Without special gear that cancels its side effects, a human cannot use it.
- **The player wields magic only through the arm** the dark entity gave him in the pact.

## Peoples

- **Dragonkin** — the born wielders of magic. The Mages are dragonkin.
- **Humans** — no magic of their own. The Guards, Rogues and Blademasters are human. A few gain access to a little of it through special gear. The **Blademaster** is one of them: he owns gear that lets him use a little magic, and he has trained to push that little to its full potential. His parry, which reflects damage back, is that magic.
- **Bull warriors** — the race of the Tanks and the Berserkers. They have a strong resistance to magic, which makes them a natural counter to mages, and their strength makes them very dangerous against humans. They can use magic, but only to infuse their gear or their own body; they cannot cast spells. Bull warriors cannot be stunned.
- **The player** — a half-breed, part dragonkin and part human. He had never wielded magic before the pact.

## Still to write

The entity, the war and its factions. See [Open questions](open-questions.md).
