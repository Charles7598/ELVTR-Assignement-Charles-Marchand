# Dark Touch — Open Questions

Decisions still to make for the [Dark Touch GDD](GDD.md). Tick an item when it is decided, then move the decision into the GDD or its companion documents.

## Combat and abilities

- [ ] The two variants of each ability.
- [ ] Instant spells: castable in the air? (for now yes, like while moving)
- [ ] Whether aimed abilities get a soft-targeting assist or stay raw aim (decided during prototyping). Week 1: a switch lets the designer compare both; final choice still open.
- [ ] The AoE rotation beyond Raw Nova, and how talismans change the rotation.
- [ ] Which variant passives give Spirit, and how much.
- [ ] How many Souls a kill gives, and how many a Reap gives.
- [ ] Other stun sources, beyond the Mage's charged spell and the Blademaster's parry; can the player stun enemies?

## Army and soldiers

- [ ] Player abilities granted by Mages, Rogues and Berserkers.
- [ ] Berserker: leap range and Whirlwind details (targeting decided: melee soldiers first, strongest first).
- [ ] Grade and rank odds per difficulty tier.
- [ ] Is the collection at the base limited in size?
- [ ] Later: the special capture mechanic (a rhythm mini-game aligning auras, or another idea).

## Enemies and level

- [ ] Enemy roster for the level: which types appear, how often, how many elites.
- [ ] The boss of the level: design and mechanics (idea: adds spawning mid-fight to switch between single target and AoE).
- [ ] Level layout: how many sections, their size and shape, what marks the exit of a section, hidden chest placement, run length for the one-level demo.

## Progression

- [ ] Talismans: stats they boost, rarity, how many can be owned, whether found ones are kept after a death; the drop rate once fight sizes are known (target: 2–3 per completed run).
- [ ] The experience curve: how much experience a run gives and how much each level needs.
- [ ] The talent list, including talents that change how Souls are gained.
- [ ] What each variant does.
- [ ] Tuning the Rank Odds board (enemies per fight, rank and grade odds) in playtests.

## Presentation

- [ ] The mantle: light physics on its back strips, or stiff skinning only?
- [ ] UI: screen order, and the UI Designer's model.
- [ ] Default assignment of the 18 key slots (12 spells, 3 golden-slot abilities, 3 command-group keys) and of the 3 orders on the order bar.
- [ ] Accessibility options, such as reducing camera shake.
- [ ] Lore beyond the opening story: the entity, the war, the factions.
- [ ] Bull warriors cannot be stunned (decided). Beyond that, does their magic resistance become a combat rule (less damage from the player's spells, resistance to roots such as Grasp), or stay lore only?

## Balance

- [ ] All numbers: damage, HP, cooldowns, cast times, Reap buff values, talisman boosts.
