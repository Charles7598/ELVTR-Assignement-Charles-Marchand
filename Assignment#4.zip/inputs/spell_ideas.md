# Spell ideas, in the designer's words (2026-11-08)

Note from the designer: « ce que j'appelle verdâtre est cette couleur cyan-turquoise ». Wherever these notes say "verdâtre", the colour is the arm's cyan-turquoise (#3FE0D0), never a true green.

## Grasp
Sur une zone en rond telle que la Raw Nova, toutes les cibles touchées prennent des dégâts faibles et sont immobilisées sur place pendant 4 secondes.
Des mains fantomatiques sortent du sol et attrapent les jambes des ennemis touchés. Pas besoin que ce soit pixel perfect, je veux juste voir 3 paires de bras qui entourent la cible au niveau des jambes. Cela doit scaler également avec la taille du mob pour que ça fasse sens et que ce soit bien visible pour chaque mob.

## Swap
Je veux que la caméra travel en premier vers la cible du swap. Pendant ce temps une fumée apparaît sur le player et le summon ciblé. Cette fumée cache le swap de position et offre une transition clean.

## Splinters
On doit aller vers des éclats de pierres taillés, des éclats de tombe dans l'idée, toujours entourés de cet effet verdâtre du bras propre aux spells.

## Raise
Le mob doit se relever lentement dans une fumée tourbillonnante vers le ciel. Ensuite pendant 2 secondes il doit léviter et changer graduellement son matériau, ainsi qu'avoir l'aura caractéristique des summons qui apparaît, puis il retombe au sol et est maintenant fonctionnel.

## Hunger
Un Niagara dans le style de l'image de référence du designer : une morsure sur le mob choisi, la couleur verdâtre et non orange.
Reference image, described: two glowing curved arcs of pointed fangs, one above and one below, snap shut on the target, then a bright four-point star flash with thin radiating sparks. Style reference only, third-party: do not name or copy it.

## Reap
La morsure fait mine de manger le cadavre pendant 2 secondes. Pendant ces deux secondes le cadavre saigne à chaque morsure, et explose doucement à la fin en mélange de sang et de magie verdâtre.

## Frenzy
Une animation de cri sur le player. Sur les soldats, leur aura double de volume et un cercle rouge transparent à leurs pieds montre qu'ils sont sous l'effet du buff.

## Rot
Designer's choice among three proposed ideas (W2-GP-14, option A): cyan-turquoise veins of rot crawl over the cursed enemy's body, spreading from where the curse landed, and pulse brighter once per second with each damage tick. A thin thread of cyan-turquoise links the arm to the target at the moment of the cast. It stays readable when several enemies are cursed at once.

## Power of Below
Une animation sur le perso, un cri aussi. On fait passer l'aura du bras sur tout le corps et on met un cercle verdâtre transparent sous le personnage pendant la durée du buff.
